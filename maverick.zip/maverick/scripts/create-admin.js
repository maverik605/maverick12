#!/usr/bin/env node
// ---------------------------------------------------------------------------
// MAVERICK — create / update the admin account
//
// Works against whatever provider is configured (Supabase or local SQLite).
// For Supabase, set the env vars first:
//
//   SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... \
//   node scripts/create-admin.js myusername mypassword
//
// Example with defaults (no args): creates / resets "admin".
// ---------------------------------------------------------------------------
const bcrypt = require("bcryptjs");
const cfg = require("../server/config");
const store = require("../server/store");

async function main() {
  const username = process.argv[2] || "admin";
  const password = process.argv[3] || "maverick2026";

  if (password.length < 8) {
    console.error("Password must be at least 8 characters long.");
    process.exit(1);
  }

  const hash = bcrypt.hashSync(password, 12);
  await store.upsertAdmin(username, hash);

  console.log(`[MAVERICK] Admin "${username}" is ready (provider: ${cfg.PROVIDER}).`);
  console.log("           Change the password and keep it safe.");
}

main().catch((e) => {
  console.error("[MAVERICK] Failed:", e.message || e);
  process.exit(1);
});
