// ---------------------------------------------------------------------------
// MAVERICK — Public site SPA (hash router)
// ---------------------------------------------------------------------------
window.MV = window.MV || {};
(function () {
  const WHATSAPP = "https://wa.me/2347087505215";
  const EMAIL = "maverickdaniel135@gmail.com";
  const PHONE = "07087505215";

  const SERVICES = [
    { icon: "voice", title: "AI Voice Agents",
      desc: "Build intelligent voice agents that can answer calls, communicate with customers, collect information, qualify leads, and perform business tasks." },
    { icon: "receptionist", title: "AI Receptionists",
      desc: "Create AI-powered receptionists that answer incoming calls and provide customers with immediate assistance." },
    { icon: "calendar", title: "AI Appointment Booking",
      desc: "Automate appointment scheduling, confirmations, reminders, and calendar management." },
    { icon: "filter", title: "AI Lead Qualification",
      desc: "Automatically communicate with leads, ask qualifying questions, collect information, and route qualified prospects to the right team." },
    { icon: "support", title: "AI Customer Support",
      desc: "Build AI-powered systems that answer customer questions and provide automated support." },
    { icon: "workflow", title: "AI Workflow Automation",
      desc: "Automate repetitive business processes and connect multiple applications into intelligent workflows." },
    { icon: "n8n", title: "n8n Automation",
      desc: "Build customized AI-powered workflows and integrations using n8n." },
    { icon: "make", title: "Make.com Automation",
      desc: "Create powerful automated workflows connecting different business applications." },
    { icon: "zapier", title: "Zapier Automation",
      desc: "Connect applications and automate repetitive tasks using Zapier." },
    { icon: "crm", title: "CRM Automation",
      desc: "Automate lead management, contact updates, follow-ups, pipeline actions, and customer workflows." },
    { icon: "whatsapp", title: "WhatsApp & SMS Automation",
      desc: "Build automated customer communication, notifications, reminders, and follow-up systems." },
    { icon: "api", title: "API Integrations",
      desc: "Connect software platforms, AI systems, CRMs, databases, and business applications using APIs." },
  ];

  const PROCESS = [
    { n: "01", title: "Discover",
      desc: "Understand the business, existing workflow, challenges, and desired outcome." },
    { n: "02", title: "Plan",
      desc: "Design the AI agent or automation architecture around the business requirements." },
    { n: "03", title: "Build",
      desc: "Develop the AI voice agent, automation workflows, integrations, and required systems." },
    { n: "04", title: "Test",
      desc: "Test the system thoroughly, identify problems, and optimize the workflow." },
    { n: "05", title: "Launch",
      desc: "Deploy the completed system and make sure everything works correctly." },
  ];

  const svg = {
    arrow: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    whatsapp: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.3c-.2.6-1.2 1.1-1.7 1.2-.4.1-1 .1-1.6-.1-.4-.1-.9-.3-1.5-.6-2.6-1.1-4.3-3.8-4.4-4-.1-.2-1.1-1.4-1.1-2.7 0-1.3.7-2 .9-2.2.2-.3.5-.4.7-.4h.5c.2 0 .4 0 .6.4.2.5.7 1.7.7 1.8.1.1.1.3 0 .4-.3.6-.7.9-.5 1.2.7 1.2 1.6 2 2.8 2.6.3.1.5.1.7-.1.2-.2.8-.9 1-1.2.2-.3.4-.2.7-.1.3.1 1.7.8 2 1 .3.2.5.3.5.4.1.2.1.7-.1 1.4Z"/></svg>',
    mail: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',
  };

  const addSvg = (icon) => {
    const map = {
      voice: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
      receptionist: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>',
      calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
      filter: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M4 6h16M7 12h10M10 18h4"/></svg>',
      support: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 12a9 9 0 0 1 18 0"/><path d="M3 12v5h4v-5M21 12v5h-4v-5"/><path d="M7 17v2a2 2 0 0 0 2 2h3"/></svg>',
      workflow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><path d="M14 6.5h.5A3.5 3.5 0 0 1 18 10v4M10 17.5H9.5A3.5 3.5 0 0 1 6 14v-4"/></svg>',
      n8n: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="12" r="9"/><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l3 3M18 18l-3-3M18 6l-3 3M6 18l3-3"/></svg>',
      make: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M20 12a8 8 0 1 1-8-8"/><path d="M20 4v8h-8"/></svg>',
      zapier: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M13 3 4 14h6l-1 7 9-11h-6l1-7Z"/></svg>',
      crm: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="7" height="18" rx="1.5"/><rect x="14" y="3" width="7" height="10" rx="1.5"/><path d="M17.5 17h0"/></svg>',
      whatsapp: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Z"/></svg>',
      api: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M8 3 3 8l5 5M16 3l5 5-5 5M13 4l-2 16"/></svg>',
      link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2"/></svg>',
    };
    return map[icon] || "";
  };

  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

  const main = document.getElementById("main");

  function revealAll() {
    requestAnimationFrame(() => {
      document.querySelectorAll(".reveal:not(.in)").forEach((el) => {
        el.classList.add("in");
      });
    });
    bindReveal();
  }

  let revealObserver = null;
  function bindReveal() {
    if (revealObserver) revealObserver.disconnect();
    revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) { e.target.classList.add("in"); revealObserver.unobserve(e.target); }
        });
      },
      { threshold: 0.12 }
    );
    document.querySelectorAll(".reveal:not(.in)").forEach((el) => revealObserver.observe(el));
  }

  const home = () => `
    <section class="hero">
      <div class="container hero-grid">
        <div class="hero-copy" style="--d:0">
          <div class="hero-tagline">MAVERICK · AI Voice Agent &amp; AI Automation Specialist</div>
          <h1 class="hero-title">Build Smarter Businesses with <em>AI Voice Agents</em> &amp; Automation</h1>
          <p class="hero-sub">I build intelligent AI voice agents and automated workflows that help businesses handle calls, qualify leads, book appointments, support customers, and eliminate repetitive manual tasks.</p>
          <div class="hero-actions">
            <a href="#/contact" class="btn btn-primary">Work With Me ${svg.arrow}</a>
            <a href="#/portfolio" class="btn btn-ghost">View Portfolio</a>
          </div>
        </div>
        <div class="hero-visual">
          <div class="call-card">
            <div class="cc-label">Live AI Call Agent</div>
            <div class="call-wave">
              <span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span>
            </div>
            <div class="call-row">
              <div class="call-text">Qualifying inbound lead...</div>
              <span class="badge pub">Live</span>
            </div>
            <div class="call-meta">Incoming call · handled automatically</div>
          </div>
          <div class="mini-stat">
            <div class="ico">${addSvg("calendar")}</div>
            <div><div class="ms-num">Unattended</div><div class="ms-label">Appointments booked 24/7</div></div>
          </div>
          <div class="mini-stat c2">
            <div class="ico">${addSvg("filter")}</div>
            <div><div class="ms-num">Qualified</div><div class="ms-label">Leads routed to the right team</div></div>
          </div>
        </div>
      </div>
    </section>

    <section class="section section-alt" id="services">
      <div class="container">
        <div class="section-head center reveal">
          <div class="eyebrow">What I Do</div>
          <h2 class="section-title">Intelligent systems, built to work</h2>
          <p class="section-subtitle">Intelligent AI systems and automation designed to make businesses more efficient.</p>
        </div>
        <div class="grid grid-3">
          ${SERVICES.map((s) => `
            <article class="service-card reveal">
              <div class="sc-icon">${addSvg(s.icon)}</div>
              <h3>${esc(s.title)}</h3>
              <p>${esc(s.desc)}</p>
            </article>`).join("")}
        </div>
      </div>
    </section>

    <section class="section" id="process">
      <div class="container">
        <div class="section-head center reveal">
          <div class="eyebrow">How I Work</div>
          <h2 class="section-title">A clear, proven process</h2>
          <p class="section-subtitle">Simple, repeatable steps that take you from idea to a fully working AI system.</p>
        </div>
        <div class="process-list">
          ${PROCESS.map((p) => `
            <div class="process-step reveal">
              <div class="process-num">${p.n}</div>
              <div><h3>${esc(p.title)}</h3><p>${esc(p.desc)}</p></div>
            </div>`).join("")}
        </div>
      </div>
    </section>

    <section class="section section-alt" id="cta-home">
      <div class="container project-cta" id="homeCta">
        <div class="section-head center reveal" style="margin-bottom:0">
          <h2 class="section-title">Ready to build something smarter?</h2>
          <p class="section-subtitle">Let's automate the repetitive work so your team can focus on what matters.</p>
          <div class="hero-actions" style="justify-content:center;margin-top:26px">
            <a href="#/contact" class="btn btn-primary">Work With Me</a>
            <a class="btn btn-whatsapp" href="${WHATSAPP}" target="_blank" rel="noopener">${svg.whatsapp} Chat on WhatsApp</a>
          </div>
        </div>
      </div>
    </section>
  `;

  const servicesPage = () => `
    <section class="section">
      <div class="container">
        <div class="breadcrumb"><a href="#/">Home</a> / Services</div>
        <div class="section-head reveal">
          <div class="eyebrow">Services</div>
          <h1 class="section-title">What I Do</h1>
          <p class="section-subtitle">Intelligent AI systems and automation designed to make businesses more efficient.</p>
        </div>
        <div class="grid grid-3">
          ${SERVICES.map((s) => `
            <article class="service-card reveal">
              <div class="sc-icon">${addSvg(s.icon)}</div>
              <h3>${esc(s.title)}</h3>
              <p>${esc(s.desc)}</p>
            </article>`).join("")}
        </div>
        <div class="section-gap"></div>
        <div class="panel text-center" style="--d:0">
          <div class="flex-between" style="justify-content:center;gap:16px">
            <a href="#/contact" class="btn btn-primary">Work With Me</a>
            <a href="#/portfolio" class="btn btn-ghost">View My Work</a>
          </div>
        </div>
      </div>
    </section>
  `;

  const processPage = () => `
    <section class="section">
      <div class="container">
        <div class="breadcrumb"><a href="#/">Home</a> / Process</div>
        <div class="section-head reveal">
          <div class="eyebrow">Process</div>
          <h1 class="section-title">How I Work</h1>
          <p class="section-subtitle">A clear, proven path from your first conversation to a fully deployed AI system.</p>
        </div>
        <div class="process-list">
          ${PROCESS.map((p) => `
            <div class="process-step reveal">
              <div class="process-num">${p.n}</div>
              <div><h3>${p.title}</h3><p>${p.desc}</p></div>
            </div>`).join("")}
        </div>
      </div>
    </section>
  `;

  // ------------------------------ Portfolio ------------------------------
  function formatDate(s) { if (!s) return ""; return new Date(s.replace(" ", "T")).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }); }

  function projectCard(p) {
    const cover = p.image_url
      ? `<img src="${esc(p.image_url)}" alt="${esc(p.project_name)}" loading="lazy" />`
      : `<div class="cover-placeholder">${esc(p.project_name.charAt(0).toUpperCase())}</div>`;
    return `
      <a class="project-card reveal" href="#/project/${p.id}">
        <div class="project-cover">
          ${p.featured ? '<span class="cover-badge">Featured</span>' : ""}
          ${cover}
        </div>
        <div class="pc-body">
          <div class="pc-cat">${esc(p.category)}</div>
          <h3>${esc(p.project_name)}</h3>
          <p>${esc(p.short_description)}</p>
          <div class="pc-foot">
            <span class="link-arrow">View Project ${svg.arrow}</span>
            <span class="muted" style="font-size:13px">${formatDate(p.project_date || p.created_at)}</span>
          </div>
        </div>
      </a>`;
  }

  let portfolioState = { page: 1, perPage: 9, category: "all", sort: "newest", featured: false, totalPages: 1, total: 0 };

  async function portfolioUI() {
    const el = document.getElementById("portfolioMount");
    el.innerHTML = `<div class="portfolio-grid"><div class="skeleton" style="height:280px"></div><div class="skeleton" style="height:280px"></div><div class="skeleton" style="height:280px"></div></div>`;

    const q = new URLSearchParams({ page: portfolioState.page, perPage: portfolioState.perPage, sort: portfolioState.sort });
    if (portfolioState.category !== "all") q.set("category", portfolioState.category);
    if (portfolioState.featured) q.set("featured", "true");

    try {
      const data = await API.get("/api/portfolio?" + q.toString());
      portfolioState.totalPages = data.totalPages;
      portfolioState.total = data.total;

      const grid = document.getElementById("portfolioGrid");
      if (data.items.length === 0) {
        el.innerHTML = `<div class="empty-state"><h3>No projects yet</h3><p>New AI voice agents and automations will appear here as they're published.</p></div>`;
        return;
      }
      grid.innerHTML = data.items.map(projectCard).join("");
    } catch (e) {
      el.innerHTML = `<div class="empty-state"><h3>Unable to load projects</h3><p>${esc(e.message)}</p></div>`;
      return;
    }
    revealAll();
  }

  async function loadCategories() {
    try {
      const data = await API.get("/api/portfolio/categories/all");
      const box = document.getElementById("categoryChips");
      if (!box) return;
      const cats = data.categories || [];
      const chips = [`<button class="chip active" data-cat="all">All</button>`]
        .concat(cats.map((c) => `<button class="chip" data-cat="${esc(c)}">${esc(c)}</button>`));
      box.innerHTML = chips.join("");
      box.querySelectorAll(".chip").forEach((b) => {
        b.addEventListener("click", () => {
          box.querySelectorAll(".chip").forEach((x) => x.classList.remove("active"));
          b.classList.add("active");
          portfolioState.category = b.dataset.cat;
          portfolioState.page = 1;
          portfolioUI();
        });
      });
    } catch (e) { /* ignore */ }
  }

  function portfolioMount() {
    return `
      <section class="section">
        <div class="container">
          <div class="breadcrumb"><a href="#/">Home</a> / Portfolio</div>
          <div class="section-head reveal">
            <div class="eyebrow">Selected Work</div>
            <h1 class="section-title">Portfolio</h1>
            <p class="section-subtitle">Explore some of the AI voice agents and automation systems I have built.</p>
          </div>
          <div class="toolbar">
            <div class="chips" id="categoryChips"></div>
            <div style="display:flex;gap:10px;flex-wrap:wrap">
              <label class="chip" style="cursor:pointer">
                <input type="checkbox" id="featToggle" style="margin-right:6px" /> Featured
              </label>
              <select id="sortSel" class="sort-select">
                <option value="newest">Newest</option>
                <option value="oldest">Oldest</option>
                <option value="name">Name A–Z</option>
              </select>
            </div>
          </div>
          <div id="portfolioMount">
            <div class="portfolio-grid" id="portfolioGrid"></div>
            <div class="pagination" id="portfolioPagination"></div>
          </div>
        </div>
      </section>`;
  }

  async function portfolioPage() {
    const el = document.createElement("div");
    el.id = "pageRoot";
    el.innerHTML = portfolioMount();
    main.innerHTML = "";
    main.appendChild(el);

    loadCategories();

    const feat = document.getElementById("featToggle");
    feat.addEventListener("change", () => { portfolioState.featured = feat.checked; portfolioState.page = 1; portfolioUI(); });
    const sortEl = document.getElementById("sortSel");
    sortEl.addEventListener("change", () => { portfolioState.sort = sortEl.value; portfolioState.page = 1; portfolioUI(); });

    await portfolioUI();
    portfolioState.page = 1;
  }

  function renderPagination() {
    const box = document.getElementById("portfolioPagination");
    if (!box) return;
    if (portfolioState.totalPages <= 1) { box.innerHTML = ""; return; }
    box.innerHTML = `
      <button class="btn btn-ghost btn-sm" id="pgPrev" ${portfolioState.page <= 1 ? "disabled" : ""}>← Prev</button>
      <span class="page-num">Page ${portfolioState.page} of ${portfolioState.totalPages}</span>
      <button class="btn btn-ghost btn-sm" id="pgNext" ${portfolioState.page >= portfolioState.totalPages ? "disabled" : ""}>Next →</button>`;
    const prev = document.getElementById("pgPrev");
    const next = document.getElementById("pgNext");
    if (prev) prev.addEventListener("click", () => { if (portfolioState.page > 1) { portfolioState.page--; portfolioUI(); } });
    if (next) next.addEventListener("click", () => { if (portfolioState.page < portfolioState.totalPages) { portfolioState.page++; portfolioUI(); } });
  }

  // Wrap portfolioUI to also render pagination
  const origPortfolioUI = portfolioUI;
  portfolioUI = async function () {
    const pag = document.getElementById("portfolioPagination");
    if (pag) pag.innerHTML = '<span class="spinner"></span>';
    const data = await fetchPortfolioData();
    if (!data) return;
    const grid = document.getElementById("portfolioGrid");
    const mount = document.getElementById("portfolioMount");
    if (grid) grid.innerHTML = data.items.map(projectCard).join("");
    if (mount && data.items.length === 0) mount.innerHTML = `<div class="empty-state"><h3>No projects yet</h3><p>New AI voice agents and automations will appear here as they're published.</p></div>`;
    portfolioState.totalPages = Math.max(1, data.totalPages);
    renderPagination();
    revealAll();
  };

  async function fetchPortfolioData() {
    const q = new URLSearchParams({ page: portfolioState.page, perPage: portfolioState.perPage, sort: portfolioState.sort });
    if (portfolioState.category !== "all") q.set("category", portfolioState.category);
    if (portfolioState.featured) q.set("featured", "true");
    try {
      const data = await API.get("/api/portfolio?" + q.toString());
      return data;
    } catch (e) { return null; }
  }

  // ------------------------------ Project detail ------------------------------
  async function projectPage(id) {
    main.innerHTML = "";
    const el = document.createElement("div");
    el.id = "pageRoot";
    el.innerHTML = `<div class="section"><div class="container"><div class="empty-state"><span class="spinner"></span></div></div></div>`;
    main.appendChild(el);
    try {
      const p = await API.get("/api/portfolio/" + id);
      const media = p.video_url
        ? (p.video_url.match(/\.(mp4|webm|ogg|mov|mkv)$/i)
            ? `<video src="${esc(p.video_url)}" controls playsinline preload="metadata"></video>`
            : `<iframe src="${esc(p.video_url)}" style="width:100%;aspect-ratio:16/9;border:0" allowfullscreen allow="autoplay; encrypted-media; picture-in-picture"></iframe>`)
        : (p.image_url
            ? `<img src="${esc(p.image_url)}" alt="${esc(p.project_name)}" />`
            : `<div class="cover-placeholder">${esc(p.project_name.charAt(0).toUpperCase())}</div>`);

      const tools = (p.technologies && p.technologies.length)
        ? `<div class="side-card"><h4>Tools &amp; Technologies</h4><div class="tags">${p.technologies.map((t) => `<span class="tag">${esc(t)}</span>`).join("")}</div></div>`
        : "";

      const demo = p.demo_url
        ? `<a class="btn btn-primary btn-block" href="${esc(p.demo_url)}" target="_blank" rel="noopener">${svg.link}&nbsp; View Live Demo</a>`
        : "";

      el.innerHTML = `
        <div class="detail-hero">
          <div class="container">
            <div class="breadcrumb"><a href="#/portfolio">Portfolio</a> / ${esc(p.project_name)}</div>
          </div>
        </div>
        <section class="section">
          <div class="container">
            <div class="detail-media">${media}</div>
            <div class="detail-layout">
              <div class="detail-body">
                <h1>${esc(p.project_name)}</h1>
                <div class="detail-desc">${esc(p.full_description).replace(/\n/g, "<br/>")}</div>
              </div>
              <div class="side-cards">
                <div class="side-card">
                  <h4>Details</h4>
                  <dl class="meta-list">
                    <dt>Category</dt><dd>${esc(p.category)}</dd>
                    ${p.project_date ? `<dt>Project date</dt><dd>${formatDate(p.project_date)}</dd>` : ""}
                    ${p.featured ? `<dt>Status</dt><dd><span class="badge featured">★ Featured</span></dd>` : ""}
                  </dl>
                  <div class="section-gap"></div>
                  ${demo}
                  <div class="section-gap"></div>
                  <div class="btn-row" style="display:flex;flex-direction:column;gap:10px">
                    <a class="btn btn-whatsapp btn-block" href="${WHATSAPP}" target="_blank" rel="noopener">${svg.whatsapp} Chat on WhatsApp</a>
                    <a class="btn btn-ghost btn-block" href="#/contact">Start a similar project</a>
                  </div>
                </div>
                ${tools}
              </div>
            </div>
          </div>
        </section>`;
      revealAll();
    } catch (e) {
      el.innerHTML = `<div class="section"><div class="container"><div class="empty-state"><h3>Project not found</h3><p>${esc(e.message)}</p></div></div></div>`;
    }
  }

  // ------------------------------ About ------------------------------
  const aboutPage = () => `
    <section class="section">
      <div class="container">
        <div class="breadcrumb"><a href="#/">Home</a> / About</div>
        <div class="about-grid">
          <div class="about-pin">
            <div class="about-card reveal">
              <div class="eyebrow">About Maverick</div>
              <h3>AI Voice Agent &amp; AI Automation Specialist</h3>
              <p>Maverick helps businesses use AI voice technology and automation to simplify operations, improve customer communication, and reduce repetitive manual work.</p>
              <p>I build practical AI systems around real business workflows, including AI voice agents, appointment booking, lead qualification, customer support, CRM automation, workflow automation, API integrations, and automated communication systems.</p>
            </div>
          </div>
          <div>
            <div class="section-head reveal" style="margin-bottom:26px">
              <h1 class="section-title">Practical AI, built around real workflows</h1>
              <p class="section-subtitle">Every system I build exists to solve a real business problem — not to chase trends. From voice agents that answer your calls to workflows that run in the background, the goal is always the same: less manual work, better customer experience, and more time for your team.</p>
            </div>
            <div class="mini-stat" style="margin-bottom:14px">
              <div class="ico">${addSvg("support")}</div>
              <div><div class="ms-num">Hands-on</div><div class="ms-label">Focus on working, reliable automation</div></div>
            </div>
            <div class="mini-stat">
              <div class="ico">${addSvg("api")}</div>
              <div><div class="ms-num">Integrated</div><div class="ms-label">Systems that connect your existing tools</div></div>
            </div>
            <div class="section-gap"></div>
            <div class="hero-actions">
              <a href="#/contact" class="btn btn-primary">Work With Me</a>
              <a href="#/portfolio" class="btn btn-ghost">View My Work</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;

  // ------------------------------ Contact ------------------------------
  const contactPage = () => `
    <section class="section">
      <div class="container">
        <div class="breadcrumb"><a href="#/">Home</a> / Contact</div>
        <div class="contact-grid">
          <div class="contact-info reveal">
            <div class="eyebrow">Contact</div>
            <h2>Let's Build Something Smarter</h2>
            <p class="section-subtitle" style="max-width:none">Have a repetitive process, customer communication problem, or business workflow that could be automated? Let's discuss how AI can help.</p>
            <div class="mini-stat" style="margin-top:26px;max-width:420px">
              <div class="ico">${addSvg("mail")}</div>
              <div><div class="ms-num" style="font-family:var(--font-body);font-size:16px;font-weight:600">${EMAIL}</div><div class="ms-label">Best for project briefs &amp; inquiries</div></div>
            </div>
            <div class="btn-row">
              <a class="btn btn-whatsapp" href="${WHATSAPP}" target="_blank" rel="noopener">${svg.whatsapp} Chat on WhatsApp</a>
              <a class="btn btn-ghost" href="mailto:${EMAIL}?subject=Project%20inquiry%20for%20MAVERICK">${svg.mail} Send Me an Email</a>
            </div>
            <p class="muted mt-2" style="font-size:14px">WhatsApp: ${PHONE} · For a faster response, WhatsApp or email are ideal.</p>
          </div>
          <form class="form reveal" id="contactForm" novalidate>
            <div id="contactAlert"></div>
            <label class="field">Name *<input name="name" required maxlength="150" placeholder="Your full name" /></label>
            <label class="field">Email *<input name="email" type="email" required maxlength="200" placeholder="you@company.com" /></label>
            <label class="field">Company<input name="company" maxlength="200" placeholder="Company / organisation (optional)" /></label>
            <label class="field">Service Needed
              <select name="service_needed">
                <option value="">Select a service…</option>
                <option>AI Voice Agent</option>
                <option>AI Receptionist</option>
                <option>AI Appointment Booking</option>
                <option>AI Lead Qualification</option>
                <option>AI Customer Support</option>
                <option>AI Workflow Automation</option>
                <option>n8n Automation</option>
                <option>Make.com Automation</option>
                <option>Zapier Automation</option>
                <option>CRM Automation</option>
                <option>WhatsApp &amp; SMS Automation</option>
                <option>API Integrations</option>
                <option>Other</option>
              </select>
            </label>
            <label class="field">Project Description *<textarea name="project_description" required maxlength="3000" rows="7" placeholder="Tell me about your process, the problem you want solved, or the workflow you'd like to automate."></textarea></label>
            <button class="btn btn-primary btn-block" type="submit">Send Message</button>
          </form>
        </div>
      </div>
    </section>
  `;

  function bindContactForm() {
    const form = document.getElementById("contactForm");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const alertBox = document.getElementById("contactAlert");
      const fd = new FormData(form);
      const payload = Object.fromEntries(fd.entries());
      const btn = form.querySelector("button[type=submit]");
      btn.disabled = true;

      const validate = () => {
        if (!payload.name.trim()) return "Please enter your name.";
        if (!payload.email.trim()) return "Please enter your email.";
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email)) return "Please enter a valid email.";
        if (!payload.project_description.trim()) return "Please describe your project.";
        return "";
      };
      const err = validate();
      if (err) {
        alertBox.innerHTML = `<div class="form-msg err">${esc(err)}</div>`;
        btn.disabled = false;
        return;
      }
      try {
        await API.post("/api/contact", payload);
        alertBox.innerHTML = `<div class="form-msg ok">Thanks — your message has been sent. I'll get back to you soon.</div>`;
        form.reset();
      } catch (e2) {
        alertBox.innerHTML = `<div class="form-msg err">${esc(e2.message)}</div>`;
      }
      btn.disabled = false;
    });
  }

  // ------------------------------ Router ------------------------------
  const routes = {
    home, services: servicesPage, process: processPage, portfolio: portfolioPage,
    about: aboutPage, contact: contactPage,
  };

  let currentRoute = "";
  async function render() {
    document.body.classList.remove("admin-mode");
    const hash = location.hash.replace(/^#\//, "") || "home";
    const navActive = document.querySelectorAll("[data-nav]");
    navActive.forEach((a) => a.classList.remove("active"));

    const setNav = (key) => {
      navActive.forEach((a) => {
        if (a.dataset.nav === key) a.classList.add("active");
      });
    };

    if (hash === "admin") {
      // Handled by admin.js via event
      window.dispatchEvent(new CustomEvent("mv:admin"));
      return;
    }

    if (hash.startsWith("project/")) {
      const id = hash.split("/")[1];
      await projectPage(id);
      setNav("portfolio");
      window.scrollTo(0, 0);
      return;
    }

    const key = hash.split("/")[0];
    const route = routes[key] || routes.home;
    closeMobileMenu();
    if (key === "portfolio") {
      await portfolioPage();
    } else {
      main.innerHTML = route();
      bindContactForm();
    }
    setNav(routes[key] ? key : "home");
    revealAll();
    window.scrollTo(0, 0);
  }

  window.addEventListener("hashchange", () => {
    if (!location.hash.startsWith("#/admin")) render();
  });
  window.addEventListener("DOMContentLoaded", () => {
    render();
    document.getElementById("year").textContent = new Date().getFullYear();
  });

  // Mobile menu
  const toggle = document.getElementById("navToggle");
  const navEl = document.getElementById("mainNav");
  toggle.addEventListener("click", () => {
    const open = navEl.classList.toggle("open");
    toggle.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", open);
  });
  function closeMobileMenu() {
    navEl.classList.remove("open");
    toggle.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  }
})();
