// ---------------------------------------------------------------------------
// MAVERICK — Admin dashboard
// ---------------------------------------------------------------------------
(function () {
  const main = document.getElementById("main");
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

  const CATEGORIES = [
    "AI Voice Agent", "AI Automation", "n8n", "Make.com", "Zapier",
    "CRM Automation", "WhatsApp Automation", "Other",
  ];
  const TOOL_SUGGESTIONS = [
    "n8n", "Make.com", "Zapier", "GoHighLevel", "Twilio", "OpenAI",
    "ElevenLabs", "APIs", "Webhooks", "Airtable", "Google Sheets",
    "Cald.com", "Calendly", "HubSpot", "Salesforce",
  ];
  const WHATSAPP = "https://wa.me/2347087505215";
  const EMAIL = "maverickdaniel135@gmail.com";

  const addSvg = (name) => {
    const map = {
      grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
      edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
      trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/><path d="M10 11v6M14 11v6"/></svg>',
      eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
      plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
      back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
      logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>',
    };
    return map[name] || "";
  };

  const iconBtn = (name, action, cls) =>
    `<button class="icon-btn ${cls || ""}" data-act="${action}" title="${name}">${addSvg(name)}</button>`;

  let admin = { username: "" };
  let projState = { page: 1, perPage: 10, search: "", category: "all", sort: "newest", featured: false, published: "all" };
  let msgState = { page: 1, perPage: 15, status: "all", search: "" };

  function toast(text, type) {
    let wrap = document.querySelector(".toast-wrap");
    if (!wrap) { wrap = document.createElement("div"); wrap.className = "toast-wrap"; document.body.appendChild(wrap); }
    const t = document.createElement("div");
    t.className = "toast " + (type || "");
    t.textContent = text;
    wrap.appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; t.style.transition = "opacity .4s"; setTimeout(() => t.remove(), 400); }, 2800);
  }

  function shell(active, inner) {
    const nav = [
      ["dashboard", "Dashboard"],
      ["projects", "Projects"],
      ["add", "Add Project"],
      ["messages", "Messages"],
    ];
    return `
      <div class="admin-shell">
        <div class="admin-topbar">
          <div class="container header-inner">
            <a href="#/admin/dashboard" class="brand">
              <span class="brand-mark">M</span>
              <span class="brand-name">MAVERICK</span>
            </a>
            <nav class="admin-nav">
              ${nav.map(([k, label]) => `<a href="#/admin/${k}" class="${k === active ? "active" : ""}">${label}</a>`).join("")}
            </nav>
            <span class="muted" style="color:rgba(255,255,255,.7)"></span>
            <button class="btn btn-ghost btn-sm" style="border-color:rgba(255,255,255,.3);color:#fff" id="logoutBtn">${addSvg("logout")}&nbsp; Logout</button>
          </div>
        </div>
        <div class="container admin-wrap">
          ${inner}
        </div>
      </div>`;
  }

  // --------------------------- LOGIN ---------------------------
  async function showLogin() {
    main.innerHTML = `
      <div class="login-wrap">
        <div class="login-card">
          <div class="brand"><span class="brand-mark">M</span><span class="brand-name">MAVERICK</span></div>
          <h1>Admin Login</h1>
          <p class="sub">Secure access to the MAVERICK management dashboard.</p>
          <div id="loginAlert"></div>
          <form id="loginForm">
            <label class="field">Username<input name="username" required autocomplete="username" /></label>
            <label class="field">Password<input name="password" type="password" required autocomplete="current-password" /></label>
            <button class="btn btn-primary btn-block" type="submit">Sign In</button>
          </form>
          <p class="muted text-center mt-2" style="font-size:13px"><a href="#/" class="btn-link">← Back to website</a></p>
        </div>
      </div>`;
    document.getElementById("loginForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const alertBox = document.getElementById("loginAlert");
      const btn = e.target.querySelector("button");
      btn.disabled = true;
      const fd = new FormData(e.target);
      try {
        const res = await API.post("/api/auth/login", { username: fd.get("username"), password: fd.get("password") });
        admin.username = res.username;
        toast("Signed in", "ok");
        runAdmin();
      } catch (err) {
        alertBox.innerHTML = `<div class="form-msg err">${esc(err.error || err.message || "Login failed")}</div>`;
        btn.disabled = false;
      }
    });
  }

  async function logout() {
    try { await API.post("/api/auth/logout"); } catch (e) {}
    toast("Signed out");
    window.location.hash = "#/admin";
    showLogin();
  }

  // --------------------------- DASHBOARD ---------------------------
  async function showDashboard() {
    let data;
    try { data = await API.get("/api/admin/stats"); }
    catch (e) { return showLogin(); }

    const stat = (num, label) => `<div class="stat-card"><div class="s-num">${esc(num)}</div><div class="s-label">${esc(label)}</div></div>`;

    const recentProjRows = (data.recentProjects && data.recentProjects.length)
      ? data.recentProjects.map((p) => `
          <tr>
            <td><strong>${esc(p.project_name)}</strong></td>
            <td>${esc(p.category)}</td>
            <td>${p.featured ? '<span class="badge featured">Featured</span>' : ""} ${p.published ? '<span class="badge pub">Published</span>' : '<span class="badge draft">Draft</span>'}</td>
            <td class="muted">${esc(p.created_at || "")}</td>
            <td><a class="btn-link" href="#/admin/edit/${p.id}">Edit</a></td>
          </tr>`).join("")
      : `<tr><td colspan="5" class="muted">No projects yet.</td></tr>`;

    const recentMsgRows = (data.recentMessages && data.recentMessages.length)
      ? data.recentMessages.map((m) => `
          <tr>
            <td><strong>${esc(m.name)}</strong></td>
            <td>${esc(m.email)}</td>
            <td>${esc(m.service_needed || "—")}</td>
            <td>${m.status === "unread" ? '<span class="badge unread">Unread</span>' : '<span class="badge read">Read</span>'}</td>
            <td class="muted">${esc(m.created_at || "")}</td>
          </tr>`).join("")
      : `<tr><td colspan="5" class="muted">No messages yet.</td></tr>`;

    main.innerHTML = shell("dashboard", `
      <div class="flex-between crumb-line"><a href="#/admin/dashboard">Dashboard</a><span class="muted">Welcome back, ${esc(admin.username)}</span></div>
      <div class="stat-grid">
        ${stat(data.totalProjects, "Total Projects")}
        ${stat(data.publishedProjects, "Published")}
        ${stat(data.totalMessages, "Contact Messages")}
        ${stat(data.unreadMessages, "Unread Messages")}
      </div>
      <div class="flex-between mb-2">
        <h3 style="margin:0">Recent Projects</h3>
        <a href="#/admin/add" class="btn btn-primary btn-sm">${addSvg("plus")}&nbsp; Add Project</a>
      </div>
      <div class="panel" style="margin-bottom:26px">
        <div class="table-wrap"><table>
          <thead><tr><th>Name</th><th>Category</th><th>Status</th><th>Created</th><th></th></tr></thead>
          <tbody>${recentProjRows}</tbody>
        </table></div>
      </div>
      <h3 style="margin:0 0 14px">Recent Contact Messages</h3>
      <div class="panel">
        <div class="table-wrap"><table>
          <thead><tr><th>Name</th><th>Email</th><th>Service</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>${recentMsgRows}</tbody>
        </table></div>
      </div>
    `);
    document.getElementById("logoutBtn").addEventListener("click", logout);
  }

  // --------------------------- PROJECTS LIST ---------------------------
  async function showProjects() {
    // Build toolbar UI
    const buildToolbar = () => `
      <div class="flex-between crumb-line">
        <a href="#/admin/dashboard">Dashboard</a>
        <a href="#/admin/add" class="btn btn-primary btn-sm">${addSvg("plus")}&nbsp; Add Project</a>
      </div>
      <div class="panel" style="margin-bottom:22px">
        <div class="admin-row" style="margin-bottom:0;gap:12px">
          <input class="sort-select" id="projSearch" placeholder="Search projects…" style="min-width:200px" />
          <select class="sort-select" id="projCat">
            <option value="all">All categories</option>
            ${CATEGORIES.map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join("")}
          </select>
          <select class="sort-select" id="projSort">
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
            <option value="name">Name A–Z</option>
          </select>
          <select class="sort-select" id="projPub">
            <option value="all">Any status</option>
            <option value="true">Published</option>
            <option value="false">Draft</option>
          </select>
          <label class="chip" style="cursor:pointer"><input type="checkbox" id="projFeat" style="margin-right:6px"/> Featured only</label>
        </div>
      </div>
      <div id="projMount"><div class="empty-state"><span class="spinner"></span></div></div>`;

    main.innerHTML = shell("projects", buildToolbar());
    document.getElementById("logoutBtn").addEventListener("click", logout);

    const fetchProj = async () => {
      const mount = document.getElementById("projMount");
      const q = new URLSearchParams({ page: projState.page, perPage: projState.perPage, sort: projState.sort });
      if (projState.search) q.set("search", projState.search);
      if (projState.category !== "all") q.set("category", projState.category);
      if (projState.featured) q.set("featured", "true");
      if (projState.published !== "all") q.set("published", projState.published);
      let data;
      try { data = await API.get("/api/admin/portfolio?" + q.toString()); }
      catch (e) { if (e.status === 401) return showLogin(); mount.innerHTML = `<div class="empty-state">${esc(e.error || e.message)}</div>`; return; }

      if (data.items.length === 0) {
        mount.innerHTML = `<div class="empty-state"><h3>No projects found</h3><p>Adjust your filters, or add your first project.</p><div class="mt-2"><a href="#/admin/add" class="btn btn-primary btn-sm">${addSvg("plus")}&nbsp; Add Project</a></div></div>`;
        return;
      }
      const rows = data.items.map((p) => `
        <tr>
          <td>${p.image_url ? `<img class="thumb" src="${esc(p.image_url)}" alt="" loading="lazy"/>` : `<span class="thumb-ph">${esc(p.project_name.charAt(0))}</span>`}</td>
          <td><strong>${esc(p.project_name)}</strong></td>
          <td>${esc(p.category)}</td>
          <td>${p.featured ? '<span class="badge featured">Featured</span>' : `<span class="muted">—</span>`}</td>
          <td>${p.published ? '<span class="badge pub">Published</span>' : '<span class="badge draft">Draft</span>'}</td>
          <td class="muted">${esc((p.project_date || p.created_at || "").slice(0, 10))}</td>
          <td>
            <div class="actions">
              <a class="icon-btn" href="#/project/${p.id}" title="View on site">${addSvg("eye")}</a>
              <a class="icon-btn" href="#/admin/edit/${p.id}" title="Edit">${addSvg("edit")}</a>
              <button class="icon-btn danger" data-del="${p.id}" title="Delete">${addSvg("trash")}</button>
            </div>
          </td>
        </tr>`).join("");

      mount.innerHTML = `
        <div class="panel"><div class="table-wrap"><table>
          <thead><tr><th></th><th>Name</th><th>Category</th><th>Featured</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
          <tbody>${rows}</tbody>
        </table></div></div>
        <div class="pagination">
          <button class="btn btn-ghost btn-sm" id="pgPrev" ${data.page <= 1 ? "disabled" : ""}>← Prev</button>
          <span class="page-num">Page ${data.page} of ${data.totalPages} (${data.total} projects)</span>
          <button class="btn btn-ghost btn-sm" id="pgNext" ${data.page >= data.totalPages ? "disabled" : ""}>Next →</button>
        </div>`;

      mount.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => confirmDelete(b.dataset.del, b)));
      bindAdminPagination(mount);
    };

    const searchIn = document.getElementById("projSearch");
    let debounce;
    searchIn.addEventListener("input", () => { clearTimeout(debounce); debounce = setTimeout(() => { projState.search = searchIn.value; projState.page = 1; fetchProj(); }, 350); });
    document.getElementById("projCat").addEventListener("change", (e) => { projState.category = e.target.value; projState.page = 1; fetchProj(); });
    document.getElementById("projSort").addEventListener("change", (e) => { projState.sort = e.target.value; projState.page = 1; fetchProj(); });
    document.getElementById("projPub").addEventListener("change", (e) => { projState.published = e.target.value; projState.page = 1; fetchProj(); });
    document.getElementById("projFeat").addEventListener("change", (e) => { projState.featured = e.target.checked; projState.page = 1; fetchProj(); });

    fetchProj();
  }

  function bindAdminPagination(mount) {
    const prev = mount.querySelector("#pgPrev");
    const next = mount.querySelector("#pgNext");
    if (prev) prev.addEventListener("click", () => { if (projState.page > 1) { projState.page--; fetchAdminPage(); } });
    if (next) next.addEventListener("click", () => { projState.page++; fetchAdminPage(); });
  }

  async function fetchAdminPage() {
    const q = new URLSearchParams({ page: projState.page, perPage: projState.perPage, sort: projState.sort });
    if (projState.search) q.set("search", projState.search);
    if (projState.category !== "all") q.set("category", projState.category);
    if (projState.featured) q.set("featured", "true");
    if (projState.published !== "all") q.set("published", projState.published);
    const data = await API.get("/api/admin/portfolio?" + q.toString());
    const mount = document.getElementById("projMount");
    if (!data.items.length) { mount.innerHTML = `<div class="empty-state"><h3>No projects found</h3></div>`; return; }
    const rows = data.items.map((p) => `
      <tr>
        <td>${p.image_url ? `<img class="thumb" src="${esc(p.image_url)}" alt="" loading="lazy"/>` : `<span class="thumb-ph">${esc(p.project_name.charAt(0))}</span>`}</td>
        <td><strong>${esc(p.project_name)}</strong></td>
        <td>${esc(p.category)}</td>
        <td>${p.featured ? '<span class="badge featured">Featured</span>' : `<span class="muted">—</span>`}</td>
        <td>${p.published ? '<span class="badge pub">Published</span>' : '<span class="badge draft">Draft</span>'}</td>
        <td class="muted">${esc((p.project_date || p.created_at || "").slice(0, 10))}</td>
        <td><div class="actions">
          <a class="icon-btn" href="#/project/${p.id}" title="View">${addSvg("eye")}</a>
          <a class="icon-btn" href="#/admin/edit/${p.id}" title="Edit">${addSvg("edit")}</a>
          <button class="icon-btn danger" data-del="${p.id}" title="Delete">${addSvg("trash")}</button>
        </div></td>
      </tr>`).join("");
    mount.innerHTML = `
      <div class="panel"><div class="table-wrap"><table>
        <thead><tr><th></th><th>Name</th><th>Category</th><th>Featured</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>${rows}</tbody>
      </table></div></div>
      <div class="pagination">
        <button class="btn btn-ghost btn-sm" id="pgPrev" ${data.page <= 1 ? "disabled" : ""}>← Prev</button>
        <span class="page-num">Page ${data.page} of ${data.totalPages} (${data.total})</span>
        <button class="btn btn-ghost btn-sm" id="pgNext" ${data.page >= data.totalPages ? "disabled" : ""}>Next →</button>
      </div>`;
    mount.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => confirmDelete(b.dataset.del, b)));
    bindAdminPagination(mount);
  }

  async function confirmDelete(id, btn) {
    if (!confirm("Delete this project permanently? This cannot be undone.")) return;
    try {
      await API.del("/api/admin/portfolio/" + id);
      toast("Project deleted", "ok");
      btn.closest("tr") && btn.closest("tr").remove();
    } catch (e) { toast(e.error || e.message, "err"); }
  }

  // --------------------------- ADD / EDIT FORM ---------------------------
  async function showAdd(id) {
    let p = null;
    if (id) {
      try { p = await API.get("/api/admin/portfolio/" + id); }
      catch (e) { if (e.status === 401) return showLogin(); return toast(e.error, "err"); }
    }
    const isEdit = !!id;
    const title = isEdit ? "Edit Project" : "Add Project";
    const defaultCat = p ? p.category : "AI Voice Agent";

    main.innerHTML = shell(isEdit ? "projects" : "add", `
      <div class="flex-between crumb-line">
        <a href="#/admin/dashboard">Dashboard</a>
        <a href="#/admin/projects" class="btn btn-ghost btn-sm">${addSvg("back")}&nbsp; Back to Projects</a>
      </div>
      <div class="panel">
        <h3>${title}</h3>
        <p class="sub">${isEdit ? "Changes save instantly and update the public portfolio." : "Create a new portfolio project. You can save as a draft or publish it."}</p>
        <div id="formAlert"></div>
        <form id="projForm">
          <label class="field">Project Name *<input name="project_name" required maxlength="200" value="${esc(p ? p.project_name : "")}" placeholder="e.g. AI Voice Receptionist for a Dental Clinic" /></label>
          <label class="field">Short Description <span class="hint">For the portfolio card (max 500 chars)</span><input name="short_description" maxlength="500" value="${esc(p ? p.short_description : "")}" placeholder="One or two sentences shown on the project card." /></label>
          <label class="field">Full Description <span class="hint">Max 3,000 characters.</span>
            <textarea name="full_description" maxlength="3000" rows="9" id="fullDesc" placeholder="Describe the project, the problem it solves, and the outcome. Up to 3,000 characters.">${esc(p ? p.full_description : "")}</textarea>
          </label>
          <div class="char-counter" id="charCounter">0 / 3000 characters</div>

          <div class="section-gap"></div>
          <div class="form-row">
            <label class="field">Category *
              <input name="category" list="catList" maxlength="100" value="${esc(defaultCat)}" placeholder="Choose or type a category" />
              <datalist id="catList">${CATEGORIES.map((c) => `<option value="${esc(c)}">`).join("")}</datalist>
            </label>
            <label class="field">Project Date <input name="project_date" type="date" value="${esc(p ? (p.project_date || "").slice(0, 10) : "")}" /></label>
          </div>

          <label class="field">Tools / Technologies <span class="hint">Separate each with a comma</span>
            <input name="technologies" id="techInput" value="${esc(p ? (p.technologies || []).join(", ") : "")}" placeholder="n8n, Twilio, OpenAI, ElevenLabs, Webhooks" />
          </label>
          <div id="toolSuggest" class="tags" style="gap:8px;margin-bottom:20px">
            ${TOOL_SUGGESTIONS.map((t) => `<button type="button" class="tag" data-tool="${esc(t)}" style="cursor:pointer;border:1px solid var(--border);background:var(--bg)">+ ${esc(t)}</button>`).join("")}
          </div>

          <div class="form-row">
            <label class="field">Project Image
              <div class="dropzone" id="imgDrop"><div class="dz-label">Click to upload an image</div><div class="dz-hint">JPG, PNG, WEBP · shows on the project card</div></div>
              <div class="upload-preview hidden" id="imgPreview"><img id="imgPreviewEl"/><button type="button" class="icon-btn rm danger" id="imgRemove">${addSvg("trash")}</button></div>
              <input type="hidden" name="image_path" id="imagePath" value="${esc(p ? (p.image_url || "") : "")}" />
            </label>
            <label class="field">Project Video
              <div class="dropzone" id="vidDrop"><div class="dz-label">Click to upload a video</div><div class="dz-hint">MP4, WEBM · up to 120MB</div></div>
              <input name="video_url" id="videoUrl" class="mt-1" placeholder="…or paste a video URL (YouTube / .mp4)" value="${esc(p ? (p.video_url || "") : "")}" />
              <div class="upload-preview hidden" id="vidPreview"><video id="vidPreviewEl" controls style="max-height:180px;width:100%"></video><button type="button" class="icon-btn rm danger" id="vidRemove">${addSvg("trash")}</button></div>
            </label>
          </div>

          <label class="field">Demo URL <input name="demo_url" value="${esc(p ? (p.demo_url || "") : "")}" placeholder="https://… (optional live link)" /></label>

          <div class="section-gap"></div>
          <div class="switch-row"><span><strong>Featured project</strong><br/><span class="muted" style="font-size:13px">Highlight on portfolio</span></span>
            <label class="switch"><input type="checkbox" name="featured" ${p && p.featured ? "checked" : ""}/><span class="slider"></span></label></div>
          <div class="switch-row"><span><strong>Published</strong><br/><span class="muted" style="font-size:13px">Visible on the public site</span></span>
            <label class="switch"><input type="checkbox" name="published" ${!isEdit || (p && p.published) ? "checked" : ""}/><span class="slider"></span></label></div>

          <div class="section-gap"></div>
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${isEdit ? "Save Changes" : "Create Project"}</button>
            <button class="btn btn-ghost" type="button" id="saveDraftBtn">${isEdit ? "Save as Draft" : "Save as Draft"}</button>
            <a class="btn btn-ghost" href="#/admin/projects">Cancel</a>
          </div>
        </form>
      </div>
    `);
    document.getElementById("logoutBtn").addEventListener("click", logout);

    // Character counter
    const desc = document.getElementById("fullDesc");
    const counter = document.getElementById("charCounter");
    const validate = () => {
      const len = desc.value.length;
      counter.textContent = `${len} / 3000 characters`;
      if (len > 3000) { counter.classList.add("over"); desc.value = desc.value.slice(0, 3000); counter.textContent = "3000 / 3000 characters"; counter.classList.remove("over"); }
      else counter.classList.remove("over");
    };
    desc.addEventListener("input", validate);
    validate();

    // Tool chips
    document.getElementById("toolSuggest").addEventListener("click", (e) => {
      if (e.target.closest("[data-tool]")) {
        const t = e.target.closest("[data-tool]").dataset.tool;
        const input = document.getElementById("techInput");
        const cur = input.value.split(",").map((x) => x.trim()).filter(Boolean);
        if (!cur.includes(t)) { cur.push(t); input.value = cur.join(", "); }
      }
    });

    // Image upload
    const imgPath = document.getElementById("imagePath");
    const imgPreview = document.getElementById("imgPreview");
    const imgPreviewEl = document.getElementById("imgPreviewEl");
    const imgRemove = document.getElementById("imgRemove");
    if (p && p.image_url) {
      imgPreview.classList.remove("hidden");
      imgPreviewEl.src = p.image_url;
    }
    setupUpload("imgDrop", "image", (data) => {
      imgPath.value = data.url;
      imgPreview.classList.remove("hidden"); imgPreviewEl.src = data.url;
    });
    imgRemove.addEventListener("click", () => { imgPath.value = ""; imgPreview.classList.add("hidden"); });

    // Video upload
    const videoUrl = document.getElementById("videoUrl");
    const vidPreview = document.getElementById("vidPreview");
    const vidPreviewEl = document.getElementById("vidPreviewEl");
    const vidRemove = document.getElementById("vidRemove");
    if (p && p.video_url) { vidPreview.classList.remove("hidden"); vidPreviewEl.src = p.video_url; }
    setupUpload("vidDrop", "video", (data) => { videoUrl.value = data.url; vidPreview.classList.remove("hidden"); vidPreviewEl.src = data.url; });
    videoUrl.addEventListener("input", () => { const url = videoUrl.value.trim(); if (url) { vidPreview.classList.remove("hidden"); vidPreviewEl.src = url; } else { vidPreview.classList.add("hidden"); } });
    vidRemove.addEventListener("click", () => { videoUrl.value = ""; vidPreview.classList.add("hidden"); });

    const submit = async (published) => {
      const alertBox = document.getElementById("formAlert");
      const btn = document.querySelector("#projForm [type=submit]");
      const payload = {
        project_name: document.querySelector('[name=project_name]').value,
        short_description: document.querySelector('[name=short_description]').value,
        full_description: desc.value,
        category: document.querySelector('[name=category]').value || "Other",
        technologies: document.getElementById("techInput").value.split(",").map((s) => s.trim()).filter(Boolean),
        image_url: imgPath.value,
        video_url: videoUrl.value,
        demo_url: document.querySelector('[name=demo_url]').value,
        project_date: document.querySelector('[name=project_date]').value,
        featured: document.querySelector('[name=featured]').checked ? 1 : 0,
        published: published ? 1 : 0,
      };
      if (!payload.project_name.trim()) { alertBox.innerHTML = `<div class="form-msg err">Project name is required.</div>`; return; }
      if (desc.value.length > 3000) { alertBox.innerHTML = `<div class="form-msg err">Full description exceeds 3,000 characters.</div>`; return; }
      btn.disabled = true;
      try {
        if (isEdit) { await API.put("/api/admin/portfolio/" + id, payload); }
        else { await API.post("/api/admin/portfolio", payload); }
        toast(isEdit ? "Project updated" : "Project created", "ok");
        window.location.hash = "#/admin/projects";
      } catch (e) {
        alertBox.innerHTML = `<div class="form-msg err">${esc(e.error || e.message)}</div>`;
        btn.disabled = false;
      }
    };
    document.getElementById("projForm").addEventListener("submit", (e) => { e.preventDefault(); submit(true); });
    document.getElementById("saveDraftBtn").addEventListener("click", () => submit(false));
  }

  function setupUpload(dropId, kind, onDone) {
    const drop = document.getElementById(dropId);
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = kind === "image" ? "image/*" : "video/*";
    fileInput.style.display = "none";
    drop.appendChild(fileInput);
    drop.addEventListener("click", () => fileInput.click());
    drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("drag"); });
    drop.addEventListener("dragleave", () => drop.classList.remove("drag"));
    drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("drag"); if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); });
    fileInput.addEventListener("change", () => { if (fileInput.files[0]) handleFile(fileInput.files[0]); });
    async function handleFile(file) {
      drop.querySelector(".dz-label").textContent = "Uploading…";
      try {
        const data = await API.upload({ file, kind });
        onDone(data);
        toast("Uploaded", "ok");
      } catch (e) {
        toast("Upload failed: " + (e.message || "Invalid file"), "err");
      }
      drop.querySelector(".dz-label").textContent = kind === "image" ? "Click to upload an image" : "Click to upload a video";
    }
  }

  // --------------------------- MESSAGES ---------------------------
  async function showMessages() {
    main.innerHTML = shell("messages", `
      <div class="flex-between crumb-line"><a href="#/admin/dashboard">Dashboard</a><span class="muted">Contact submissions</span></div>
      <div class="panel" style="margin-bottom:22px">
        <div class="admin-row" style="margin-bottom:0;gap:12px">
          <input class="sort-select" id="msgSearch" placeholder="Search messages…" style="min-width:200px" />
          <select class="sort-select" id="msgStatus">
            <option value="all">Any status</option>
            <option value="unread">Unread</option>
            <option value="read">Read</option>
          </select>
        </div>
      </div>
      <div id="msgMount"><div class="empty-state"><span class="spinner"></span></div></div>
    `);
    document.getElementById("logoutBtn").addEventListener("click", logout);

    const fetchMsgs = async () => {
      const mount = document.getElementById("msgMount");
      const q = new URLSearchParams({ page: msgState.page, perPage: msgState.perPage });
      if (msgState.search) q.set("search", msgState.search);
      if (msgState.status !== "all") q.set("status", msgState.status);
      let data;
      try { data = await API.get("/api/admin/contact?" + q.toString()); }
      catch (e) { if (e.status === 401) return showLogin(); mount.innerHTML = `<div class="empty-state">${esc(e.error)}</div>`; return; }
      if (!data.items.length) { mount.innerHTML = `<div class="empty-state"><h3>No messages</h3><p>Contact form submissions will appear here.</p></div>`; return; }
      const rows = data.items.map((m) => `
        <tr>
          <td><strong>${esc(m.name)}</strong></td>
          <td><a href="mailto:${esc(m.email)}" class="btn-link">${esc(m.email)}</a></td>
          <td>${esc(m.company || "—")}</td>
          <td>${esc(m.service_needed || "—")}</td>
          <td>${m.status === "unread" ? '<span class="badge unread">Unread</span>' : '<span class="badge read">Read</span>'}</td>
          <td class="muted">${esc(m.created_at || "")}</td>
          <td><div class="actions">
            <button class="icon-btn" data-toggle="${m.id}" data-status="${m.status === "unread" ? "read" : "unread"}" title="Toggle read">${addSvg("eye")}</button>
            <button class="icon-btn danger" data-msgdel="${m.id}" title="Delete">${addSvg("trash")}</button>
          </div></td>
        </tr>
        ${m.project_description ? `<tr class="msg-desc" data-desc="${m.id}"><td colspan="7" style="color:var(--muted)">${esc(m.project_description)}</td></tr>` : ""}
      `).join("");
      mount.innerHTML = `
        <div class="panel"><div class="table-wrap"><table>
          <thead><tr><th>Name</th><th>Email</th><th>Company</th><th>Service</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
          <tbody>${rows}</tbody>
        </table></div></div>
        <div class="pagination">
          <button class="btn btn-ghost btn-sm" id="msgPrev" ${data.page <= 1 ? "disabled" : ""}>← Prev</button>
          <span class="page-num">Page ${data.page} of ${data.totalPages}</span>
          <button class="btn btn-ghost btn-sm" id="msgNext" ${data.page >= data.totalPages ? "disabled" : ""}>Next →</button>
        </div>`;

      mount.querySelectorAll("[data-toggle]").forEach((b) => b.addEventListener("click", async () => {
        try { await API.patch("/api/admin/contact/" + b.dataset.toggle, { status: b.dataset.status }); toast("Status updated", "ok"); fetchMsgs(); }
        catch (e) { toast(e.error, "err"); }
      }));
      mount.querySelectorAll("[data-msgdel]").forEach((b) => b.addEventListener("click", async () => {
        if (!confirm("Delete this message?")) return;
        try { await API.del("/api/admin/contact/" + b.dataset.msgdel); toast("Deleted", "ok"); fetchMsgs(); }
        catch (e) { toast(e.error, "err"); }
      }));
      const prev = mount.querySelector("#msgPrev"); const next = mount.querySelector("#msgNext");
      if (prev) prev.addEventListener("click", () => { if (msgState.page > 1) { msgState.page--; fetchMsgs(); } });
      if (next) next.addEventListener("click", () => { msgState.page++; fetchMsgs(); });
    };

    let debounce;
    document.getElementById("msgSearch").addEventListener("input", (e) => { clearTimeout(debounce); debounce = setTimeout(() => { msgState.search = e.target.value; msgState.page = 1; fetchMsgs(); }, 350); });
    document.getElementById("msgStatus").addEventListener("change", (e) => { msgState.status = e.target.value; msgState.page = 1; fetchMsgs(); });
    fetchMsgs();
  }

  // --------------------------- ROUTER ---------------------------
  async function runAdmin() {
    document.body.classList.add("admin-mode");
    // verify session
    try {
      const me = await API.get("/api/auth/me");
      admin.username = me.username;
    } catch (e) {
      return showLogin();
    }
    const seg = location.hash.replace(/^#\/admin\/?/, "") || "dashboard";
    const [route, id] = seg.split("/");
    if (route === "dashboard") return showDashboard();
    if (route === "projects") return showProjects();
    if (route === "add") return showAdd();
    if (route === "edit") return showAdd(id);
    if (route === "messages") return showMessages();
    if (route === "login") return showLogin();
    return showDashboard();
  }

  window.addEventListener("hashchange", () => {
    if (location.hash.startsWith("#/admin")) runAdmin();
  });

  // Expose for app.js to trigger
  window.__runAdmin = runAdmin;
})();
