// ---------------------------------------------------------------------------
// MAVERICK — wiring bridge: run the admin app when the router requests it
// ---------------------------------------------------------------------------
window.addEventListener("mv:admin", function () {
  if (window.__runAdmin) window.__runAdmin();
});
