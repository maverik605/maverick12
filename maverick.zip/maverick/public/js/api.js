// ---------------------------------------------------------------------------
// MAVERICK — API client
// ---------------------------------------------------------------------------
window.API = (function () {
  async function request(path, options) {
    const opts = options || {};
    const fetchOpts = {
      method: opts.method || "GET",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
    };
    if (opts.body !== undefined) fetchOpts.body = JSON.stringify(opts.body);

    const res = await fetch(path, fetchOpts);
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }

    if (!res.ok) {
      const err = new Error((data && data.error) || "Request failed");
      err.status = res.status;
      throw err;
    }
    return data;
  }

  // Uploads an image/video.
  //  - Supabase mode: browser PUTs directly to a signed Storage URL.
  //  - Local mode:    falls back to the multipart /api/admin/media route.
  async function upload({ file, kind }) {
    kind = kind || (file.type && file.type.indexOf("video") === 0 ? "video" : "image");
    const extPart = (file.name.match(/\.([a-zA-Z0-9]+)$/) || [])[1] || "";

    // Try the signed-URL (Supabase) path first.
    try {
      const urlRes = await fetch(
        "/api/admin/media-url?kind=" + kind + "&ext=" + encodeURIComponent(extPart),
        { credentials: "same-origin" }
      );
      const body = await urlRes.json().catch(() => ({}));
      if (urlRes.ok && body.signedUrl) {
        const put = await fetch(body.signedUrl, {
          method: "PUT",
          headers: {
            "Content-Type": file.type || "application/octet-stream",
            "x-upsert": "true",
          },
          body: file,
        });
        if (!put.ok) throw new Error("Upload to storage failed");
        return { url: body.publicUrl, provider: "supabase" };
      }
      // If it's a 4xx meaning the feature isn't enabled, fall through to local.
      if (urlRes.status >= 500) {
        const e = new Error(body.error || "Upload failed");
        e.status = urlRes.status;
        throw e;
      }
    } catch (err) {
      if (err && err.status) throw err;
    }

    // Fallback: local multipart upload.
    const form = new FormData();
    form.append("file", file, file.name);
    const res = await fetch("/api/admin/media", {
      method: "POST",
      credentials: "same-origin",
      body: form,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Upload failed");
    return { url: data.url, provider: "local" };
  }

  return {
    get: (p) => request(p),
    post: (p, b) => request(p, { method: "POST", body: b }),
    put: (p, b) => request(p, { method: "PUT", body: b }),
    patch: (p, b) => request(p, { method: "PATCH", body: b }),
    del: (p) => request(p, { method: "DELETE" }),
    upload,
  };
})();
