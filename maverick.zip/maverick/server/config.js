// ---------------------------------------------------------------------------
// MAVERICK — runtime configuration
//
// PROVIDER:
//   "supabase"  — uses Supabase Postgres + Storage (production / Vercel).
//                 Enabled automatically when SUPABASE_URL & SERVICE KEY are set.
//   "sqlite"    — local file database (default, zero-config, great for dev).
// ---------------------------------------------------------------------------
const SUPABASE_URL = (process.env.SUPABASE_URL || "").replace(/\/$/, "");
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || "";

const PROVIDER =
  SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY ? "supabase" : "sqlite";

// Storage bucket name for media (Supabase Storage).
const STORAGE_BUCKET =
  process.env.SUPABASE_STORAGE_BUCKET || "maverick-media";

module.exports = {
  PROVIDER,
  SUPABASE_URL,
  SUPABASE_SERVICE_ROLE_KEY,
  SUPABASE_ANON_KEY,
  STORAGE_BUCKET,
  PORT: process.env.PORT || 3001,
  DB_PATH: process.env.DB_PATH,
  SESSION_TTL_MS: 1000 * 60 * 60 * 24 * 7, // 7 days
};
