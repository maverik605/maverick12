// ---------------------------------------------------------------------------
// MAVERICK — Express app (API + static site + media)
// Works against SQLite (local) or Supabase (production) via server/store.
// ---------------------------------------------------------------------------
const path = require("path");
const fs = require("fs");
const express = require("express");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const multer = require("multer");

const cfg = require("./config");
const store = require("./store");
const { createSession, destroySession, getAdminByToken } = require("./auth");

const app = express();
const PUBLIC_DIR = path.join(__dirname, "..", "public");

// Where project media (images/videos) is stored & served from.
// Railway sets MEDIA_DIR to a persistent volume path so files survive redeploys.
const UPLOAD_DIR = process.env.MEDIA_DIR || path.join(PUBLIC_DIR, "uploads");
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.disable("x-powered-by");
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
app.use(express.static(PUBLIC_DIR));
// Serve uploaded media from its (possibly volume-based) directory.
app.use("/uploads", express.static(UPLOAD_DIR));

// Health check (used by Railway / uptime monitors).
app.get("/health", (req, res) => res.json({ ok: true, provider: cfg.PROVIDER }));

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------
const MAX_DESC = 3000;

function cleanStr(v) {
  if (v === null || v === undefined) return "";
  return String(v).trim();
}

function cleanArr(v) {
  if (!Array.isArray(v)) return [];
  return v.map(cleanStr).filter(Boolean);
}

function paginate(query, defaults) {
  const d = defaults || {};
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const perPage = Math.min(
    100,
    Math.max(1, parseInt(query.perPage, 10) || (d.perPage || 9))
  );
  return { page, perPage, offset: (page - 1) * perPage };
}

function nowStr() {
  return new Date().toISOString();
}

function validateProject(body, partial) {
  const errors = [];
  const name = cleanStr(body.project_name);
  const shortDesc = cleanStr(body.short_description);
  const fullDesc = cleanStr(body.full_description);

  if (!partial || body.project_name !== undefined) {
    if (!name) errors.push("Project name is required.");
    if (name.length > 200) errors.push("Project name is too long (max 200).");
  }
  if (shortDesc.length > 500)
    errors.push("Short description is too long (max 500).");
  if (fullDesc.length > MAX_DESC) {
    errors.push("Full description exceeds the 3,000 character limit.");
  }
  if (!partial || body.category !== undefined) {
    if (cleanStr(body.category).length > 100) errors.push("Category is too long (max 100).");
  }
  return {
    errors,
    fields: {
      project_name: name,
      short_description: shortDesc,
      full_description: fullDesc,
      category: cleanStr(body.category) || "Other",
      technologies: cleanArr(body.technologies),
      image_url: cleanStr(body.image_url) || null,
      video_url: cleanStr(body.video_url) || null,
      demo_url: cleanStr(body.demo_url) || null,
      featured: body.featured ? true : false,
      published: body.published ? true : false,
      project_date: cleanStr(body.project_date) || null,
    },
  };
}

async function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies.mv_token;
  const admin = await getAdminByToken(token);
  if (!admin) return res.status(401).json({ error: "Unauthorized" });
  req.admin = admin;
  req.token = token;
  next();
}

// ---------------------------------------------------------------------------
// AUTH (custom session auth — sessions stored in the active DB)
// ---------------------------------------------------------------------------
app.post("/api/auth/login", async (req, res) => {
  const username = cleanStr(req.body.username);
  const password = cleanStr(req.body.password);
  if (!username || !password)
    return res.status(400).json({ error: "Username and password are required." });

  let admin;
  try {
    admin = await store.findAdmin(username);
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }

  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    return res.status(401).json({ error: "Invalid credentials." });
  }

  const token = await createSession(admin.id);
  res.cookie("mv_token", token, {
    httpOnly: true,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 24 * 7,
    path: "/",
    secure: process.env.NODE_ENV === "production",
  });
  return res.json({ ok: true, username: admin.username });
});

app.post("/api/auth/logout", async (req, res) => {
  await destroySession(req.cookies && req.cookies.mv_token);
  res.clearCookie("mv_token");
  return res.json({ ok: true });
});

app.get("/api/auth/me", requireAuth, (req, res) =>
  res.json({ username: req.admin.username })
);

// ---------------------------------------------------------------------------
// PUBLIC PORTFOLIO
// ---------------------------------------------------------------------------
app.get("/api/portfolio", async (req, res) => {
  const { page, perPage, offset } = paginate(req.query, { perPage: 9 });
  const filters = {
    page, perPage, offset,
    category: req.query.category || "all",
    featured: req.query.featured === "true" || req.query.featured === "1",
    sort: req.query.sort || "newest",
    published: "all",
  };
  try {
    const { items, total } = await store.listProjectsPublic(filters);
    res.json({ items, total, page, perPage, totalPages: Math.max(1, Math.ceil(total / perPage)) });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.get("/api/portfolio/:id", async (req, res) => {
  try {
    const p = await store.getProjectPublic(parseInt(req.params.id, 10));
    if (!p) return res.status(404).json({ error: "Project not found." });
    res.json(p);
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.get("/api/portfolio/categories/all", async (req, res) => {
  try {
    const categories = await store.listCategoriesPublic();
    res.json({ categories });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

// ---------------------------------------------------------------------------
// PUBLIC CONTACT
// ---------------------------------------------------------------------------
app.post("/api/contact", async (req, res) => {
  const name = cleanStr(req.body.name);
  const email = cleanStr(req.body.email);
  const company = cleanStr(req.body.company);
  const service = cleanStr(req.body.service_needed);
  const description = cleanStr(req.body.project_description);

  const errors = [];
  if (!name) errors.push("Name is required.");
  if (!email) errors.push("Email is required.");
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push("Email is invalid.");
  if (name.length > 150) errors.push("Name is too long.");
  if (email.length > 200) errors.push("Email is too long.");
  if (company.length > 200) errors.push("Company is too long.");
  if (service.length > 150) errors.push("Service is too long.");
  if (description.length > 3000) errors.push("Message is too long.");
  if (errors.length) return res.status(400).json({ error: errors.join(" ") });

  try {
    await store.createMessage({ name, email, company, service_needed: service, project_description: description });
    return res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

// ---------------------------------------------------------------------------
// ADMIN — stats
// ---------------------------------------------------------------------------
app.get("/api/admin/stats", requireAuth, async (req, res) => {
  try {
    const data = await store.stats();
    res.json(data);
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

// ---------------------------------------------------------------------------
// ADMIN — portfolio CRUD
// ---------------------------------------------------------------------------
app.get("/api/admin/portfolio", requireAuth, async (req, res) => {
  const { page, perPage, offset } = paginate(req.query, { perPage: 10 });
  const filters = {
    page, perPage, offset,
    search: cleanStr(req.query.search),
    category: req.query.category || "all",
    featured: req.query.featured === "true" || req.query.featured === "1",
    published: req.query.published !== undefined ? req.query.published : "all",
    sort: req.query.sort || "newest",
  };
  try {
    const { items, total } = await store.listProjectsAdmin(filters);
    res.json({ items, total, page, perPage, totalPages: Math.max(1, Math.ceil(total / perPage)) });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.get("/api/admin/portfolio/:id", requireAuth, async (req, res) => {
  try {
    const p = await store.getProjectAdmin(parseInt(req.params.id, 10));
    if (!p) return res.status(404).json({ error: "Project not found." });
    res.json(p);
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.post("/api/admin/portfolio", requireAuth, async (req, res) => {
  const { errors, fields } = validateProject(req.body, false);
  if (errors.length) return res.status(400).json({ error: errors.join(" ") });
  try {
    const id = await store.createProject(fields);
    res.json({ ok: true, id });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.put("/api/admin/portfolio/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const existing = await store.getProjectAdmin(id);
  if (!existing) return res.status(404).json({ error: "Project not found." });

  const { errors, fields } = validateProject(req.body, true);
  if (errors.length) return res.status(400).json({ error: errors.join(" ") });

  // Merge with existing so partial updates retain untouched fields.
  const merged = {
    ...existing,
    ...fields,
    project_name: fields.project_name || existing.project_name,
    short_description: fields.short_description !== null && fields.short_description !== "" ? fields.short_description : existing.short_description,
    full_description: fields.full_description !== null && fields.full_description !== "" ? fields.full_description : existing.full_description,
  };
  try {
    await store.updateProject(id, merged);
    res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.delete("/api/admin/portfolio/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id, 10);
  try {
    const row = await store.deleteProject(id);
    if (!row) return res.status(404).json({ error: "Project not found." });
    // Best-effort media cleanup (Supabase mode removes from Storage; local removes files).
    if (cfg.PROVIDER === "supabase") {
      const paths = [row.image_url, row.video_url].filter(
        (u) => u && u.indexOf("/object/public/" + cfg.STORAGE_BUCKET + "/") !== -1
      ).map((u) => u.split("/object/public/" + cfg.STORAGE_BUCKET + "/")[1]);
      try { await store.removeFiles(paths); } catch (e) {}
    } else {
      [row.image_url, row.video_url].forEach((u) => {
        try {
          if (u && u.startsWith("/uploads/")) {
            const fp = path.join(UPLOAD_DIR, path.basename(u));
            if (fs.existsSync(fp)) fs.unlinkSync(fp);
          }
        } catch (e) {}
      });
    }
    res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

// ---------------------------------------------------------------------------
// ADMIN — contact messages
// ---------------------------------------------------------------------------
app.get("/api/admin/contact", requireAuth, async (req, res) => {
  const { page, perPage, offset } = paginate(req.query, { perPage: 15 });
  try {
    const { items, total } = await store.listMessages({
      page, perPage, offset,
      status: req.query.status || "all",
      search: cleanStr(req.query.search),
    });
    res.json({ items, total, page, perPage, totalPages: Math.max(1, Math.ceil(total / perPage)) });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.patch("/api/admin/contact/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const status = req.body.status === "unread" || req.body.status === "read" ? req.body.status : "unread";
  try {
    await store.setMessageStatus(id, status);
    res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

app.delete("/api/admin/contact/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id, 10);
  try {
    await store.deleteMessage(id);
    res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

// ---------------------------------------------------------------------------
// MEDIA UPLOAD
//   SUPABASE: browser uploads directly to Storage via a signed URL.
//   SQLITE:   multer stores the file on disk under /uploads.
// ---------------------------------------------------------------------------
app.get("/api/admin/media-url", requireAuth, async (req, res) => {
  if (cfg.PROVIDER !== "supabase") return res.status(400).json({ error: "Not available." });
  const kind = req.query.kind === "video" ? "video" : "image";
  const ext = (req.query.ext || "").replace(/[^a-z0-9]/gi, "").slice(0, 8).toLowerCase() || (kind === "video" ? "mp4" : "jpg");
  const path_ = `admin/${Date.now()}_${Math.round(Math.random() * 1e8)}.${ext}`;
  try {
    const { data, error } = await store.createSignedUploadUrl(path_);
    if (error) return res.status(400).json({ error: error.message });
    return res.json({
      signedUrl: data.signedUrl,
      token: data.token,
      path: data.path,
      publicUrl: store.publicUrl(path_),
    });
  } catch (e) {
    return res.status(500).json({ error: "Server error." });
  }
});

// Local (SQLite) disk upload for dev/testing.
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase();
    cb(null, "mv_" + Date.now() + "_" + Math.round(Math.random() * 1e8) + ext);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 120 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const name = (file.originalname || "").toLowerCase();
    const mime = (file.mimetype || "").toLowerCase();
    const isImage = /^image\/(jpeg|png|webp|gif|svg\+xml)$/.test(mime) || /\.(jpe?g|png|webp|gif|svg)$/.test(name);
    const isVideo = /^video\//.test(mime) || /\.(mp4|webm|mov|ogg|mkv)$/.test(name);
    return cb(null, isImage || isVideo);
  },
});
app.post("/api/admin/media", requireAuth, upload.single("file"), (req, res) => {
  if (cfg.PROVIDER === "supabase") return res.status(400).json({ error: "Use /api/admin/media-url instead." });
  if (!req.file) return res.status(400).json({ error: "No valid file uploaded." });
  res.json({ ok: true, url: "/uploads/" + req.file.filename });
});

// ---------------------------------------------------------------------------
// Serve SPA for unknown non-API routes
// ---------------------------------------------------------------------------
app.get(/^\/(?!api\/).*/, (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.use((err, req, res, next) => {
  console.error("[MAVERICK] Error:", err.message);
  if (err && err.code === "LIMIT_FILE_SIZE")
    return res.status(413).json({ error: "File is too large (max 120MB)." });
  res.status(500).json({ error: "Server error." });
});

// Auto-start only when run directly (not when imported by Vercel / api/index.js).
if (require.main === module) {
  app.listen(cfg.PORT, "0.0.0.0", () => {
    console.log(`[MAVERICK] Server running on http://localhost:${cfg.PORT} [provider: ${cfg.PROVIDER}]`);
  });
}

module.exports = app;
