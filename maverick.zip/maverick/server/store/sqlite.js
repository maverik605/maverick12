// ---------------------------------------------------------------------------
// MAVERICK — SQLite store adapter (local development / zero-config)
// ---------------------------------------------------------------------------
const db = require("../db"); // this module owns the schema + seed admin

const now = () => new Date().toISOString().replace("T", " ").slice(0, 19);

const parseTech = (s) => {
  try { return JSON.parse(s || "[]"); } catch (e) { return []; }
};
const toBool = (n) => !!n;

function normalizeProject(row) {
  if (!row) return null;
  return {
    id: row.id,
    project_name: row.project_name,
    short_description: row.short_description,
    full_description: row.full_description,
    category: row.category,
    technologies: parseTech(row.technologies),
    image_url: row.image_url || "",
    video_url: row.video_url || "",
    demo_url: row.demo_url || "",
    featured: toBool(row.featured),
    published: toBool(row.published),
    project_date: row.project_date || "",
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

const store = {
  // ------------------------------ AUTH ------------------------------
  upsertAdmin(username, passwordHash) {
    db.prepare(
      `INSERT INTO admins (username, password_hash) VALUES (?, ?)
       ON CONFLICT(username) DO UPDATE SET password_hash = excluded.password_hash`
    ).run(username, passwordHash);
    return true;
  },
  findAdmin(username) {
    return db.prepare("SELECT * FROM admins WHERE username = ?").get(username) || null;
  },
  insertSession(token, adminId, expiresAt) {
    db.prepare(
      "INSERT INTO sessions (token, admin_id, expires_at) VALUES (?, ?, ?)"
    ).run(token, adminId, expiresAt);
  },
  findAdminByToken(token) {
    if (!token) return null;
    return (
      db
        .prepare(
          `SELECT a.id, a.username FROM sessions s
           JOIN admins a ON a.id = s.admin_id
           WHERE s.token = ? AND s.expires_at > datetime('now')`
        )
        .get(token) || null
    );
  },
  deleteSession(token) {
    if (token) db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
  },

  // ------------------------------ PROJECTS ------------------------------
  listProjectsPublic({ category, featured, sort, page, perPage, offset }) {
    let where = "published = 1";
    const params = [];
    if (category && category !== "all") {
      where += " AND category = ?";
      params.push(category);
    }
    if (featured) where += " AND featured = 1";

    let order = "ORDER BY created_at DESC, id DESC";
    if (sort === "oldest") order = "ORDER BY created_at ASC, id ASC";
    else if (sort === "name") order = "ORDER BY project_name ASC";

    const total = db
      .prepare(`SELECT COUNT(*) AS c FROM portfolio_projects WHERE ${where}`)
      .get(...params).c;
    const rows = db
      .prepare(
        `SELECT * FROM portfolio_projects WHERE ${where} ${order} LIMIT ? OFFSET ?`
      )
      .all(...params, perPage, offset);

    return { items: rows.map(normalizeProject), total };
  },

  getProjectPublic(id) {
    const row = db
      .prepare(
        "SELECT * FROM portfolio_projects WHERE id = ? AND published = 1"
      )
      .get(id);
    return normalizeProject(row);
  },

  listCategoriesPublic() {
    const rows = db
      .prepare(
        "SELECT DISTINCT category FROM portfolio_projects WHERE published = 1 AND category <> '' ORDER BY category"
      )
      .all();
    return rows.map((r) => r.category).filter(Boolean);
  },

  listProjectsAdmin({ search, category, featured, published, sort, page, perPage, offset }) {
    const clauses = [];
    const params = [];
    if (search) {
      clauses.push("(project_name LIKE ? OR short_description LIKE ?)");
      params.push(`%${search}%`, `%${search}%`);
    }
    if (category && category !== "all") {
      clauses.push("category = ?");
      params.push(category);
    }
    if (featured) clauses.push("featured = 1");
    if (published !== undefined && published !== null && published !== "all") {
      clauses.push("published = ?");
      params.push(published ? 1 : 0);
    }
    const where = clauses.length ? "WHERE " + clauses.join(" AND ") : "";

    let order = "ORDER BY created_at DESC, id DESC";
    if (sort === "oldest") order = "ORDER BY created_at ASC, id ASC";
    else if (sort === "name") order = "ORDER BY project_name ASC";

    const total = db
      .prepare(`SELECT COUNT(*) AS c FROM portfolio_projects ${where}`)
      .get(...params).c;
    const rows = db
      .prepare(`SELECT * FROM portfolio_projects ${where} ${order} LIMIT ? OFFSET ?`)
      .all(...params, perPage, offset);

    return { items: rows.map(normalizeProject), total };
  },

  getProjectAdmin(id) {
    return normalizeProject(
      db.prepare("SELECT * FROM portfolio_projects WHERE id = ?").get(id)
    );
  },

  createProject(f) {
    const t = now();
    const info = db
      .prepare(
        `INSERT INTO portfolio_projects
          (project_name, short_description, full_description, category,
           technologies, image_url, video_url, demo_url, featured, published,
           project_date, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        f.project_name, f.short_description, f.full_description, f.category,
        JSON.stringify(f.technologies || []), f.image_url, f.video_url, f.demo_url,
        f.featured ? 1 : 0, f.published ? 1 : 0, f.project_date, t, t
      );
    return info.lastInsertRowid;
  },

  updateProject(id, f) {
    db.prepare(
      `UPDATE portfolio_projects SET
        project_name = ?, short_description = ?, full_description = ?,
        category = ?, technologies = ?, image_url = ?, video_url = ?,
        demo_url = ?, featured = ?, published = ?, project_date = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      f.project_name, f.short_description, f.full_description, f.category,
      JSON.stringify(f.technologies || []), f.image_url, f.video_url, f.demo_url,
      f.featured ? 1 : 0, f.published ? 1 : 0, f.project_date, now(), id
    );
    return true;
  },

  deleteProject(id) {
    const row = db
      .prepare("SELECT id, image_url, video_url FROM portfolio_projects WHERE id = ?")
      .get(id);
    if (!row) return null;
    db.prepare("DELETE FROM portfolio_projects WHERE id = ?").run(id);
    return row;
  },

  // ------------------------------ MESSAGES ------------------------------
  createMessage(f) {
    db.prepare(
      `INSERT INTO contact_messages (name, email, company, service_needed, project_description)
       VALUES (?, ?, ?, ?, ?)`
    ).run(f.name, f.email, f.company, f.service_needed, f.project_description);
    return true;
  },

  listMessages({ status, search, page, perPage, offset }) {
    const clauses = [];
    const params = [];
    if (status && status !== "all") {
      clauses.push("status = ?");
      params.push(status);
    }
    if (search) {
      clauses.push("(name LIKE ? OR email LIKE ? OR company LIKE ?)");
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    const w = clauses.length ? "WHERE " + clauses.join(" AND ") : "";
    const total = db
      .prepare(`SELECT COUNT(*) AS c FROM contact_messages ${w}`)
      .get(...params).c;
    const rows = db
      .prepare(
        `SELECT id, name, email, company, service_needed, project_description,
                status, created_at
         FROM contact_messages ${w} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`
      )
      .all(...params, perPage, offset);
    return { items: rows, total };
  },

  setMessageStatus(id, status) {
    const row = db.prepare("SELECT id FROM contact_messages WHERE id = ?").get(id);
    if (!row) return false;
    db.prepare("UPDATE contact_messages SET status = ? WHERE id = ?").run(status, id);
    return true;
  },

  deleteMessage(id) {
    const row = db.prepare("SELECT id FROM contact_messages WHERE id = ?").get(id);
    if (!row) return false;
    db.prepare("DELETE FROM contact_messages WHERE id = ?").run(id);
    return true;
  },

  stats() {
    return {
      totalProjects: db.prepare("SELECT COUNT(*) AS c FROM portfolio_projects").get().c,
      publishedProjects: db.prepare("SELECT COUNT(*) AS c FROM portfolio_projects WHERE published = 1").get().c,
      totalMessages: db.prepare("SELECT COUNT(*) AS c FROM contact_messages").get().c,
      unreadMessages: db.prepare("SELECT COUNT(*) AS c FROM contact_messages WHERE status = 'unread'").get().c,
      recentProjects: db
        .prepare("SELECT id, project_name, category, featured, published, created_at FROM portfolio_projects ORDER BY created_at DESC, id DESC LIMIT 5")
        .all(),
      recentMessages: db
        .prepare("SELECT id, name, email, service_needed, status, created_at FROM contact_messages ORDER BY created_at DESC, id DESC LIMIT 5")
        .all(),
    };
  },
};

module.exports = store;
