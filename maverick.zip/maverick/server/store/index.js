// ---------------------------------------------------------------------------
// MAVERICK — select the active store provider
// ---------------------------------------------------------------------------
const cfg = require("../config");

module.exports =
  cfg.PROVIDER === "supabase" ? require("./supabase") : require("./sqlite");
