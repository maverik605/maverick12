// ---------------------------------------------------------------------------
// MAVERICK — Supabase store adapter (Postgres + Storage, production)
//
// Uses the service-role key for all internal data access. Public/anonymous
// access is governed by RLS policies defined in supabase/schema.sql, but every
// read/write in this app flows through this server, so the service role keeps
// things simple and safe. Admin actions additionally require a valid session.
// ---------------------------------------------------------------------------
const { createClient } = require("@supabase/supabase-js");
const cfg = require("../config");

if (!cfg.SUPABASE_SERVICE_ROLE_KEY || !cfg.SUPABASE_URL) {
  throw new Error(
    "Supabase store selected but SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY are missing."
  );
}

// Provide the WebSocket transport needed by supabase-js on Node 20.
let ws;
try { ws = require("ws"); } catch (e) { ws = undefined; }

const clientOptions = {
  auth: { persistSession: false, autoRefreshToken: false },
};
if (ws) clientOptions.realtime = { transport: ws };

const sb = createClient(cfg.SUPABASE_URL, cfg.SUPABASE_SERVICE_ROLE_KEY, clientOptions);

const toBool = (b) => !!b;

function normalizeProject(row) {
  if (!row) return null;
  return {
    id: row.id,
    project_name: row.project_name,
    short_description: row.short_description || "",
    full_description: row.full_description || "",
    category: row.category,
    technologies: Array.isArray(row.technologies) ? row.technologies : [],
    image_url: row.image_url || "",
    video_url: row.video_url || "",
    demo_url: row.demo_url || "",
    featured: toBool(row.featured),
    published: toBool(row.published),
    project_date: row.project_date || "",
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

function msg(raw) {
  return raw;
}

// Build the "where" for a filter set and apply filters to a Postgrest query.
function applyFilters(q, { category, featured, published, search }) {
  let query = q;
  if (category && category !== "all") query = query.eq("category", category);
  if (featured) query = query.eq("featured", true);
  if (published !== undefined && published !== null && published !== "all")
    query = query.eq("published", !!published);
  if (search) {
    const like = `%${search}%`;
    query = query.or(`project_name.ilike.${like},short_description.ilike.${like}`);
  }
  return query;
}

async function run(query) {
  const { data, error } = await query;
  if (error) throw new Error(error.message || "Database query failed");
  return data;
}

const store = {
  // ------------------------------ AUTH ------------------------------
  async upsertAdmin(username, passwordHash) {
    const { error } = await sb
      .from("admins")
      .upsert({ username, password_hash: passwordHash }, { onConflict: "username" });
    if (error) throw new Error(error.message || "Admin upsert failed");
    return true;
  },
  async findAdmin(username) {
    const rows = await run(
      sb.from("admins").select("id,username,password_hash").eq("username", username).limit(1)
    );
    return rows[0] || null;
  },
  async insertSession(token, adminId, expiresAt) {
    await run(
      sb.from("sessions").insert({ token, admin_id: adminId, expires_at: expiresAt })
    );
  },
  async findAdminByToken(token) {
    if (!token) return null;
    const rows = await run(
      sb.from("sessions")
        .select("admin:admins!sessions_admin_id_fkey(id,username)")
        .eq("token", token)
        .gt("expires_at", new Date().toISOString())
        .limit(1)
    );
    const row = rows[0];
    if (row && row.admin) return { id: row.admin.id, username: row.admin.username };
    return null;
  },
  async deleteSession(token) {
    if (!token) return;
    await run(sb.from("sessions").delete().eq("token", token));
  },

  // ------------------------------ PROJECTS ------------------------------
  async listProjectsPublic(filters) {
    const { page, perPage, offset } = pagination(filters);
    let query = sb
      .from("portfolio_projects")
      .select("*", { count: "exact" })
      .eq("published", true);
    query = applyFilters(query, filters);
    query = sortQuery(query, filters.sort);
    const { data, count, error } = await query.range(offset, offset + perPage - 1);
    if (error) throw new Error(error.message || "Query failed");
    return { items: (data || []).map(normalizeProject), total: count || 0 };
  },

  async getProjectPublic(id) {
    const rows = await run(
      sb.from("portfolio_projects").select("*").eq("id", id).eq("published", true).limit(1)
    );
    return normalizeProject(rows[0]);
  },

  async listCategoriesPublic() {
    const rows = await run(
      sb.from("portfolio_projects").select("category").eq("published", true)
    );
    const seen = new Set();
    const cats = [];
    rows.forEach((r) => {
      if (r.category && !seen.has(r.category)) {
        seen.add(r.category);
        cats.push(r.category);
      }
    });
    return cats.sort();
  },

  async listProjectsAdmin(filters) {
    const { page, perPage, offset } = pagination(filters);
    let query = sb.from("portfolio_projects").select("*", { count: "exact" });
    query = applyFilters(query, filters);
    query = sortQuery(query, filters.sort);
    const { data, count, error } = await query.range(offset, offset + perPage - 1);
    if (error) throw new Error(error.message || "Query failed");
    return { items: (data || []).map(normalizeProject), total: count || 0 };
  },

  async getProjectAdmin(id) {
    const rows = await run(
      sb.from("portfolio_projects").select("*").eq("id", id).limit(1)
    );
    return normalizeProject(rows[0]);
  },

  async createProject(f) {
    const { data, error } = await sb
      .from("portfolio_projects")
      .insert({
        project_name: f.project_name,
        short_description: f.short_description,
        full_description: f.full_description,
        category: f.category,
        technologies: f.technologies || [],
        image_url: f.image_url || null,
        video_url: f.video_url || null,
        demo_url: f.demo_url || null,
        featured: f.featured ? true : false,
        published: f.published ? true : false,
        project_date: f.project_date || null,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message || "Insert failed");
    return data.id;
  },

  async updateProject(id, f) {
    const { error } = await sb
      .from("portfolio_projects")
      .update({
        project_name: f.project_name,
        short_description: f.short_description,
        full_description: f.full_description,
        category: f.category,
        technologies: f.technologies || [],
        image_url: f.image_url || null,
        video_url: f.video_url || null,
        demo_url: f.demo_url || null,
        featured: f.featured ? true : false,
        published: f.published ? true : false,
        project_date: f.project_date || null,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id);
    if (error) throw new Error(error.message || "Update failed");
    return true;
  },

  async deleteProject(id) {
    // Capture the object path for optional storage cleanup.
    const row = await this.getProjectAdmin(id);
    const { error } = await sb.from("portfolio_projects").delete().eq("id", id);
    if (error) throw new Error(error.message || "Delete failed");
    return row ? { id: row.id, image_url: row.image_url, video_url: row.video_url } : null;
  },

  // ------------------------------ MESSAGES ------------------------------
  async createMessage(f) {
    const { error } = await sb.from("contact_messages").insert({
      name: f.name,
      email: f.email,
      company: f.company || null,
      service_needed: f.service_needed || null,
      project_description: f.project_description || null,
    });
    if (error) throw new Error(error.message || "Insert failed");
    return true;
  },

  async listMessages(filters) {
    const { page, perPage, offset } = pagination(filters);
    let query = sb.from("contact_messages").select("*", { count: "exact" });
    if (filters.status && filters.status !== "all") query = query.eq("status", filters.status);
    if (filters.search) {
      const like = `%${filters.search}%`;
      query = query.or(`name.ilike.${like},email.ilike.${like},company.ilike.${like}`);
    }
    const { data, count, error } = await query
      .order("created_at", { ascending: false })
      .range(offset, offset + perPage - 1);
    if (error) throw new Error(error.message || "Query failed");
    return { items: (data || []).map(msg), total: count || 0 };
  },

  async setMessageStatus(id, status) {
    const { error } = await sb.from("contact_messages").update({ status }).eq("id", id);
    if (error) throw new Error(error.message || "Update failed");
    return true;
  },

  async deleteMessage(id) {
    const { error } = await sb.from("contact_messages").delete().eq("id", id);
    if (error) throw new Error(error.message || "Delete failed");
    return true;
  },

  async stats() {
    const count = async (table, filter) => {
      let q = sb.from(table).select("*", { count: "exact", head: true });
      if (filter) q = filter(q);
      const { count, error } = await q;
      if (error) throw new Error(error.message || "Query failed");
      return count || 0;
    };

    const totalProjects = await count("portfolio_projects");
    const publishedProjects = await count("portfolio_projects", (q) => q.eq("published", true));
    const totalMessages = await count("contact_messages");
    const unreadMessages = await count("contact_messages", (q) => q.eq("status", "unread"));

    const recentProjects = await run(
      sb.from("portfolio_projects")
        .select("id,project_name,category,featured,published,created_at")
        .order("created_at", { ascending: false })
        .limit(5)
    );
    const recentMessages = await run(
      sb.from("contact_messages")
        .select("id,name,email,service_needed,status,created_at")
        .order("created_at", { ascending: false })
        .limit(5)
    );

    return {
      totalProjects,
      publishedProjects,
      totalMessages,
      unreadMessages,
      recentProjects,
      recentMessages,
    };
  },

  // ------------------------------ STORAGE ------------------------------
  createSignedUploadUrl(path) {
    return sb.storage.from(cfg.STORAGE_BUCKET).createSignedUploadUrl(path);
  },
  publicUrl(path) {
    return sb.storage.from(cfg.STORAGE_BUCKET).getPublicUrl(path).data.publicUrl;
  },
  async removeFiles(paths) {
    const valid = (paths || []).filter(Boolean);
    if (!valid.length) return;
    await sb.storage.from(cfg.STORAGE_BUCKET).remove(valid);
  },
};

function pagination(f) {
  const page = f.page || 1;
  const perPage = f.perPage || 9;
  return { page, perPage, offset: (page - 1) * perPage };
}

function sortQuery(q, sort) {
  const ascending = sort === "oldest" || sort === "name";
  if (sort === "name") return q.order("project_name", { ascending: true });
  return q.order("created_at", { ascending });
}

module.exports = store;
