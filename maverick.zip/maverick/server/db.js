// ---------------------------------------------------------------------------
// MAVERICK — Database layer (SQLite via better-sqlite3)
// ---------------------------------------------------------------------------
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");

const DATA_DIR = path.join(__dirname, "..", "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, "maverick.db");
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// ---------------------------------------------------------------------------
// Schema
// ---------------------------------------------------------------------------
db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  admin_id   INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS portfolio_projects (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  project_name      TEXT NOT NULL,
  short_description TEXT NOT NULL DEFAULT '',
  full_description  TEXT NOT NULL DEFAULT '',
  category          TEXT NOT NULL DEFAULT 'Other',
  technologies      TEXT NOT NULL DEFAULT '[]',   -- JSON array
  image_url         TEXT,
  video_url         TEXT,
  demo_url          TEXT,
  featured          INTEGER NOT NULL DEFAULT 0,
  published         INTEGER NOT NULL DEFAULT 0,
  project_date      TEXT,                          -- ISO date, optional
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (length(full_description) <= 3000)
);

CREATE TABLE IF NOT EXISTS contact_messages (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT NOT NULL,
  email               TEXT NOT NULL,
  company             TEXT,
  service_needed      TEXT,
  project_description TEXT,
  status              TEXT NOT NULL DEFAULT 'unread', -- 'read' | 'unread'
  created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_projects_published ON portfolio_projects(published);
CREATE INDEX IF NOT EXISTS idx_projects_category  ON portfolio_projects(category);
CREATE INDEX IF NOT EXISTS idx_projects_featured  ON portfolio_projects(featured);
CREATE INDEX IF NOT EXISTS idx_messages_status    ON contact_messages(status);
`);

// ---------------------------------------------------------------------------
// Seed default administrator if none exists
// ---------------------------------------------------------------------------
function seedAdmin() {
  const count = db.prepare("SELECT COUNT(*) AS c FROM admins").get().c;
  if (count > 0) return;

  // Default credentials — CHANGE THESE after first login.
  const username = process.env.ADMIN_USERNAME || "admin";
  const password = process.env.ADMIN_PASSWORD || "maverick2026";
  const hash = bcrypt.hashSync(password, 12);

  db.prepare(
    "INSERT INTO admins (username, password_hash) VALUES (?, ?)"
  ).run(username, hash);

  console.log(
    "[MAVERICK] Default admin created -> username: " +
      username +
      "  password: " +
      password
  );
}
seedAdmin();

module.exports = db;
