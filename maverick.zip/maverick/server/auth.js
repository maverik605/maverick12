// ---------------------------------------------------------------------------
// MAVERICK — Authentication helpers (session tokens stored in the active DB)
// ---------------------------------------------------------------------------
const crypto = require("crypto");
const cfg = require("./config");
const store = require("./store");

const nowIso = () => new Date().toISOString();

async function createSession(adminId) {
  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + cfg.SESSION_TTL_MS).toISOString();
  await store.insertSession(token, adminId, expiresAt);
  return token;
}

async function getAdminByToken(token) {
  if (!token) return null;
  return await store.findAdminByToken(token);
}

async function destroySession(token) {
  if (token) await store.deleteSession(token);
}

module.exports = { createSession, destroySession, getAdminByToken };
