-- ===========================================================================
-- MAVERICK — Supabase schema & security policies
--
-- HOW TO USE
--   1. Create a Supabase project.
--   2. Open the SQL Editor and paste + run this whole file.
--   3. Create the Storage bucket (see "STORAGE BUCKET" section below).
--   4. Set the project env vars (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY,
--      SUPABASE_ANON_KEY) on your host and run scripts/create-admin.js to add
--      the admin account.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- ADMIN AUTH (support for the app's custom session login, stored in Postgres)
-- ---------------------------------------------------------------------------
create table if not exists public.admins (
  id            bigint generated always as identity primary key,
  username      text not null unique,
  password_hash text not null,
  created_at    timestamptz not null default now()
);

create table if not exists public.sessions (
  token      text primary key,
  admin_id   bigint not null references public.admins(id) on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);

-- ---------------------------------------------------------------------------
-- PORTFOLIO PROJECTS
-- ---------------------------------------------------------------------------
create table if not exists public.portfolio_projects (
  id                bigint generated always as identity primary key,
  project_name      text not null,
  short_description text not null default '',
  full_description  text not null default '' check (char_length(full_description) <= 3000),
  category          text not null default 'Other',
  technologies      jsonb not null default '[]'::jsonb,
  image_url         text,
  video_url         text,
  demo_url          text,
  featured          boolean not null default false,
  published         boolean not null default false,
  project_date      date,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists idx_projects_published on public.portfolio_projects(published);
create index if not exists idx_projects_category  on public.portfolio_projects(category);
create index if not exists idx_projects_featured  on public.portfolio_projects(featured);
create index if not exists idx_projects_created   on public.portfolio_projects(created_at desc);

-- ---------------------------------------------------------------------------
-- CONTACT MESSAGES
-- ---------------------------------------------------------------------------
create table if not exists public.contact_messages (
  id                  bigint generated always as identity primary key,
  name                text not null,
  email               text not null,
  company             text,
  service_needed      text,
  project_description text check (char_length(project_description) <= 3000),
  status              text not null default 'unread',
  created_at          timestamptz not null default now()
);

create index if not exists idx_messages_status on public.contact_messages(status);
create index if not exists idx_messages_created on public.contact_messages(created_at desc);

-- ---------------------------------------------------------------------------
-- ROW LEVEL SECURITY
--
-- The app uses the service-role key for ALL data access (server-side), which
-- bypasses RLS. These policies simply guarantee that nothing is readable or
-- writable by the public/anon key directly, keeping the data locked down.
--
--   admins / sessions   -> no public access (service role only).
--   contact_messages    -> no public access (service role only).
--   portfolio_projects  -> public is allowed to READ published projects only
--                          (optional; the website reads via the server, so this
--                          is a safety default). Writes stay service-role only.
-- ---------------------------------------------------------------------------
alter table public.admins             enable row level security;
alter table public.sessions           enable row level security;
alter table public.contact_messages   enable row level security;
alter table public.portfolio_projects enable row level security;

-- Lock admins, sessions, and messages to the service role.
do $$
begin
  if not exists (select 1 from pg_policies where tablename = 'admins' and policyname = 'admins_no_public') then
    create policy "admins_no_public" on public.admins for all using (false) with check (false);
  end if;
  if not exists (select 1 from pg_policies where tablename = 'sessions' and policyname = 'sessions_no_public') then
    create policy "sessions_no_public" on public.sessions for all using (false) with check (false);
  end if;
  if not exists (select 1 from pg_policies where tablename = 'contact_messages' and policyname = 'msgs_no_public') then
    create policy "msgs_no_public" on public.contact_messages for all using (false) with check (false);
  end if;
end $$;

-- Public can read published projects (optional read-only for safety).
do $$
begin
  if not exists (select 1 from pg_policies where tablename = 'portfolio_projects' and policyname = 'projects_read_published') then
    create policy "projects_read_published" on public.portfolio_projects
      for select using (published = true);
  end if;
  if not exists (select 1 from pg_policies where tablename = 'portfolio_projects' and policyname = 'projects_no_write') then
    create policy "projects_no_write" on public.portfolio_projects
      for all using (false) with check (false);
  end if;
end $$;

-- ===========================================================================
-- STORAGE BUCKET  (for project images & videos)
--
-- Run this in the Supabase dashboard:  Storage -> New bucket
--   Name:  maverick-media        (must match SUPABASE_STORAGE_BUCKET)
--   Public:  ON  (so images/videos are served with public URLs)
--
-- Optional copyable SQL alternative (dashboard is recommended for the bucket
-- because the signed-upload + public-read combo is easiest to configure there):
-- ===========================================================================
-- insert into storage.buckets (id, name, public)
--   values ('maverick-media', 'maverick-media', true)
--   on conflict (id) do nothing;
--
-- -- Allow anonymous signed uploads (the app issues signed URLs via the
-- -- service-role; this policy covers uploads to the bucket).
-- create policy "maverick_upload" on storage.objects
--   for insert to anon with check (bucket_id = 'maverick-media');
--
-- create policy "maverick_public_read" on storage.objects
--   for select using (bucket_id = 'maverick-media');
-- ===========================================================================

-- Optionally enable the `uuid-ossp`/`pgcrypto` extensions if your app needs
-- them. Not required by the default MAVERICK schema.
-- create extension if not exists "pgcrypto";
