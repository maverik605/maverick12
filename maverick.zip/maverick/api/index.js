// ---------------------------------------------------------------------------
// MAVERICK — Vercel serverless entry
// Exposes the Express app at /api/*  and serves the static frontend from /public.
// ---------------------------------------------------------------------------
const app = require("../server/index");
module.exports = app;
